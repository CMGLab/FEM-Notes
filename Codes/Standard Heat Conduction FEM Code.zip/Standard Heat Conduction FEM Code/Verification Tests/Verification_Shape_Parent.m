%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Verification Test: Parent Element Shape Functions
%
% Purpose: In this verification test, parent element shape functions are
%          are computed and plotted.  This allows for verification by
%          visual inspection for triangular elements of degree k = 1,2,3
%          and for quadrilateral elements of degree 1,2.  Additionally,
%          the script confirms shape functions sum to one and their 
%          derivatives sum to zero.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Triangular Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%
% Establish Grid for Plotting

[Xi_1_pre,Xi_2_pre] = meshgrid(linspace(0,1,20),linspace(0,1,20));

Xi_1_pre = reshape(Xi_1_pre,[400,1]);
Xi_2_pre = reshape(Xi_2_pre,[400,1]);

n = 0;

for i = 1:400
    xi_1 = Xi_1_pre(i);
    xi_2 = Xi_2_pre(i);
    
    if xi_1 + xi_2 <= 1
        n = n+1;
        Xi_1(n) = xi_1;
        Xi_2(n) = xi_2;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 1;
Nhat = zeros(n,3);

val_ver_test = 0;
der_ver_test = 0;

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    
    if abs(sum(Nhat_pt) - 1) >= 1e-10
        val_ver_test = 1;
    end
    
    if abs(sum(Nhat_xi_pt)) >= 1e-10
        der_ver_test = 1;
    end
    
    for j = 1:3
        Nhat(i,j) = Nhat_pt(j);
    end
end

%%%
% Results of Verification Tests

if val_ver_test == 0
    fprintf('TRI k = 1 basis function verification test passed.\n')
else
    cprintf('_red','TRI k = 1 basis function verification test failed!\n')
end

if der_ver_test == 0
    fprintf('TRI k = 1 derivative verification test passed.\n')
else
    cprintf('_red','TRI k = 1 derivative verification test failed!\n')
end

%%%
% Basis Function Plots
    
figure(1)

scatter3(Xi_1,Xi_2,Nhat(:,1))
hold on
scatter3(0,0,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
title('TRI $k = 1$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(2)

scatter3(Xi_1,Xi_2,Nhat(:,2))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
title('TRI $k = 1$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(3)

scatter3(Xi_1,Xi_2,Nhat(:,3))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
title('TRI $k = 1$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;
Nhat = zeros(n,6);

val_ver_test = 0;
der_ver_test = 0;

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    
    if abs(sum(Nhat_pt) - 1) >= 1e-10
        val_ver_test = 1;
    end
    
    if abs(sum(Nhat_xi_pt)) >= 1e-10
        der_ver_test = 1;
    end
    
    for j = 1:6
        Nhat(i,j) = Nhat_pt(j);
    end
end

%%%
% Results of Verification Tests

if val_ver_test == 0
    fprintf('TRI k = 2 basis function verification test passed.\n')
else
    cprintf('_red','TRI k = 2 basis function verification test failed!\n')
end

if der_ver_test == 0
    fprintf('TRI k = 2 derivative verification test passed.\n')
else
    cprintf('_red','TRI k = 2 derivative verification test failed!\n')
end

%%%
% Basis Function Plots

figure(4)

scatter3(Xi_1,Xi_2,Nhat(:,1))
hold on
scatter3(0,0,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(5)

scatter3(Xi_1,Xi_2,Nhat(:,2))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(6)

scatter3(Xi_1,Xi_2,Nhat(:,3))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(7)

scatter3(Xi_1,Xi_2,Nhat(:,4))
hold on
scatter3(0,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0.5,0,1,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(8)

scatter3(Xi_1,Xi_2,Nhat(:,5))
hold on
scatter3(0,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,1,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_5(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(9)

scatter3(Xi_1,Xi_2,Nhat(:,6))
hold on
scatter3(0,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,1,50,'k*')
title('TRI $k = 2$: $\hat{N}_6(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 3
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 3;
Nhat = zeros(n,10);

val_ver_test = 0;
der_ver_test = 0;

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    
    if abs(sum(Nhat_pt) - 1) >= 1e-10
        val_ver_test = 1;
    end
    
    if abs(sum(Nhat_xi_pt)) >= 1e-10
        der_ver_test = 1;
    end
    
    for j = 1:10
        Nhat(i,j) = Nhat_pt(j);
    end
end

%%%
% Results of Verification Tests

if val_ver_test == 0
    fprintf('TRI k = 3 basis function verification test passed.\n')
else
    cprintf('_red','TRI k = 3 basis function verification test failed!\n')
end

if der_ver_test == 0
    fprintf('TRI k = 3 derivative verification test passed.\n')
else
    cprintf('_red','TRI k = 3 derivative verification test failed!\n')
end

%%%
% Basis Function Plots

figure(10)

scatter3(Xi_1,Xi_2,Nhat(:,1))
hold on
scatter3(0,0,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(11)

scatter3(Xi_1,Xi_2,Nhat(:,2))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(12)

scatter3(Xi_1,Xi_2,Nhat(:,3))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(13)

scatter3(Xi_1,Xi_2,Nhat(:,4))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,1,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(14)

scatter3(Xi_1,Xi_2,Nhat(:,5))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,1,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_5(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(15)

scatter3(Xi_1,Xi_2,Nhat(:,6))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,1,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_6(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(16)

scatter3(Xi_1,Xi_2,Nhat(:,7))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,1,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_7(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(17)

scatter3(Xi_1,Xi_2,Nhat(:,8))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,1,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_8(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(18)

scatter3(Xi_1,Xi_2,Nhat(:,9))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,1,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_9(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(19)

scatter3(Xi_1,Xi_2,Nhat(:,10))
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,1,50,'k*')
title('TRI $k = 3$: $\hat{N}_{10}(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quadrilateral Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%
% Establish Grid for Plotting

[Xi_1,Xi_2] = meshgrid(linspace(-1,1,20),linspace(-1,1,20));

Xi_1 = reshape(Xi_1,[400,1]);
Xi_2 = reshape(Xi_2,[400,1]);

n = 400;

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 1;
Nhat = zeros(n,4);

val_ver_test = 0;
der_ver_test = 0;

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('QUAD',k,xi_1,xi_2);
    
    if abs(sum(Nhat_pt) - 1) >= 1e-10
        val_ver_test = 1;
    end
    
    if abs(sum(Nhat_xi_pt)) >= 1e-10
        der_ver_test = 1;
    end
    
    for j = 1:4
        Nhat(i,j) = Nhat_pt(j);
    end
end

%%%
% Results of Verification Tests

if val_ver_test == 0
    fprintf('QUAD k = 1 basis function verification test passed.\n')
else
    cprintf('_red','QUAD k = 1 basis function verification test failed!\n')
end

if der_ver_test == 0
    fprintf('QUAD k = 1 derivative verification test passed.\n')
else
    cprintf('_red','QUAD k = 1 derivative verification test failed!\n')
end

%%%
% Basis Function Plots

figure(20)

scatter3(Xi_1,Xi_2,Nhat(:,1))
hold on
scatter3(-1,-1,1,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
title('QUAD $k = 1$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(21)

scatter3(Xi_1,Xi_2,Nhat(:,2))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,1,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
title('QUAD $k = 1$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(22)

scatter3(Xi_1,Xi_2,Nhat(:,3))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,1,50,'k*')
scatter3(-1,1,0,50,'k*')
title('QUAD $k = 1$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(23)

scatter3(Xi_1,Xi_2,Nhat(:,4))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,1,50,'k*')
title('QUAD $k = 1$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;
Nhat = zeros(n,9);

val_ver_test = 0;
der_ver_test = 0;

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('QUAD',k,xi_1,xi_2);
    
    if abs(sum(Nhat_pt) - 1) >= 1e-10
        val_ver_test = 1;
    end
    
    if abs(sum(Nhat_xi_pt)) >= 1e-10
        der_ver_test = 1;
    end
    
    for j = 1:9
        Nhat(i,j) = Nhat_pt(j);
    end
end

%%%
% Results of Verification Tests

if val_ver_test == 0
    fprintf('QUAD k = 2 basis function verification test passed.\n')
else
    cprintf('_red','QUAD k = 2 basis function verification test failed!\n')
end

if der_ver_test == 0
    fprintf('QUAD k = 2 derivative verification test passed.\n')
else
    cprintf('_red','QUAD k = 2 derivative verification test failed!\n')
end

%%%
% Basis Function Plots

figure(24)

scatter3(Xi_1,Xi_2,Nhat(:,1))
hold on
scatter3(-1,-1,1,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('QUAD $k = 2$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(25)

scatter3(Xi_1,Xi_2,Nhat(:,2))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,1,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('QUAD $k = 2$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(26)

scatter3(Xi_1,Xi_2,Nhat(:,3))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,1,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('QUAD $k = 2$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(27)

scatter3(Xi_1,Xi_2,Nhat(:,4))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,1,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('QUAD $k = 2$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(28)

scatter3(Xi_1,Xi_2,Nhat(:,5))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('QUAD $k = 2$: $\hat{N}_5(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(29)

scatter3(Xi_1,Xi_2,Nhat(:,6))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('QUAD $k = 2$: $\hat{N}_6(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(30)

scatter3(Xi_1,Xi_2,Nhat(:,7))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('QUAD $k = 2$: $\hat{N}_7(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(31)

scatter3(Xi_1,Xi_2,Nhat(:,8))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,1,50,'k*')
scatter3(0,0,0,50,'k*')
title('QUAD $k = 2$: $\hat{N}_8(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(32)

scatter3(Xi_1,Xi_2,Nhat(:,9))
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,1,50,'k*')
title('QUAD $k = 2$: $\hat{N}_9(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)