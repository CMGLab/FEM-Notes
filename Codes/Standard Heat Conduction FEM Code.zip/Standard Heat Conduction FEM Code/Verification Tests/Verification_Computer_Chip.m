%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Verification Test: Computer Chip Problem
%
% Purpose: In this verification test, the FEA code is applied to heating
%          of a silicon chip inside of a silicon wafer.  The chip is of
%          square shape, has width 5 mm, and is located in the middle of
%          the wafer.  The wafer is of circular shape and has radius 12.5
%          mm.  The wafer is being cooled by forced air.  The thermal
%          conductivity of silicon is 157 Watts per meter per degree
%          Celcius and the convective heat transfer coefficient is 250
%          Watts per square meter per degree Celsius.  The surrounding air
%          is 30 degrees Celsius, and the applied heating is 40 Watts per
%          square mm.  This script analyzes the max temperature under mesh
%          refinement and produces VTK files for visualization in Paraview
%          for triangular elements of degree k = 2.  Note a maximum 
%          temperature of about 83 degrees is expected.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Material Parameter, Loading, and Boundary Condition Function Handles
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

kappa = @(x,y,i) kappa_computer_chip(x,y,i);
f = @(x,y,i) f_computer_chip(x,y,i);
g = @(x,y,i) g_computer_chip(x,y,i);
h = @(x,y,i) h_computer_chip(x,y,i);
beta = @(x,y,i) beta_computer_chip(x,y,i);
T_R = @(x,y,i) T_R_computer_chip(x,y,i);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Triangular Mesh and Polynomial Degree k = 2

k = 2;
SHAPE = 'TRI';

%%%
% 0 Refinement

FILE = 'Meshes/Computer_Chip/Computer_Chip_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
Max_Temperature(1) = max(Temperature);
NDOF(1) = size(Nodes,1);

FILE = 'Temperature_r0.vtk';
VTK_Writer(FILE,SHAPE,IEN,Nodes,Temperature);

%%%
% 1 Refinement

FILE = 'Meshes/Computer_Chip/Computer_Chip_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
Max_Temperature(2) = max(Temperature);
NDOF(2) = size(Nodes,1);

FILE = 'Temperature_r1.vtk';
VTK_Writer(FILE,SHAPE,IEN,Nodes,Temperature);

%%%
% 2 Refinement

FILE = 'Meshes/Computer_Chip/Computer_Chip_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
Max_Temperature(3) = max(Temperature);
NDOF(3) = size(Nodes,1);

FILE = 'Temperature_r2.vtk';
VTK_Writer(FILE,SHAPE,IEN,Nodes,Temperature);

%%%
% 3 Refinement

FILE = 'Meshes/Computer_Chip/Computer_Chip_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
Max_Temperature(4) = max(Temperature);
NDOF(4) = size(Nodes,1);

FILE = 'Temperature_r3.vtk';
VTK_Writer(FILE,SHAPE,IEN,Nodes,Temperature);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot Max Temperature Convergence

figure(1)

semilogx(NDOF,Max_Temperature)
title('Predicted Max Temperature','interpreter','latex','FontSize',16)
xlabel('$NDOF$','interpreter','latex','FontSize',16)
ylabel('Max Temperature','interpreter','latex','FontSize',16)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Material Parameter, Loading, and Boundary Condition Functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function kappa = kappa_computer_chip(x,y,i)
    switch i
        case 1
            kappa = 157;
        case 2
            kappa = 157;
    end
end

function f = f_computer_chip(x,y,i)
    switch i
        case 1
            f = 0;
        case 2
            f = 40000000;
    end
end

function g = g_computer_chip(x,y,i)
    g = 70;
end

function h = h_computer_chip(x,y,i)
    h = 0;
end

function beta = beta_computer_chip(x,y,i)
    beta = 250;
end

function T_R = T_R_computer_chip(x,y,i)
    T_R = 30;
end