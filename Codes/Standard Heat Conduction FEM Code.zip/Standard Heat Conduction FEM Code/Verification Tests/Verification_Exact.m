%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Verification Test: Exact Solution
%
% Purpose: In this verification test, the FEA code is applied to a problem
%          with an exact solution: heat conduction through a pipe.  The
%          inner radius of the pipe is taken to be 40 mm and the outer
%          radius is taken to be 50 mm.  The inner temperature is set to
%          200 degrees Celsius and the outer temperature is set to 70
%          degrees Celsius.  The pipe is assumed made of copper, which has
%          a thermal conductivity of 385 Watts per meter per degree
%          Celsius.  The exact solution is then axisymmetric and equal to:
%
%             T(r) = (T_o*ln(r/r_i) - T_i*ln(r/r_o))/ln(r_o/r_i)
%
%          where r_i and T_i are the inner radius and temperature and r_o
%          and T_o are the outer radius and temperature.  Convergence is 
%          assessed for all element types.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Exact Solution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_exact = @(x,y) (70*log(sqrt(x^2+y^2)/0.04)-200*log(sqrt(x^2+y^2)/0.05))/log(0.05/0.04);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Material Parameter, Loading, and Boundary Condition Function Handles
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

kappa = @(x,y,i) kappa_exact(x,y,i);
f = @(x,y,i) f_exact(x,y,i);
g = @(x,y,i) g_exact(x,y,i);
h = @(x,y,i) h_exact(x,y,i);
beta = @(x,y,i) beta_exact(x,y,i);
T_R = @(x,y,i) T_R_exact(x,y,i);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Triangular Study
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1 Study

k = 1;
SHAPE = 'TRI';

%%%
% 0 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k1_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k1_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k1_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);

%%%
% 3 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k1_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2 Study

k = 2;
SHAPE = 'TRI';

%%%
% 0 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k2_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k2_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k2_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);

%%%
% 3 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k2_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 3 Study

k = 3;
SHAPE = 'TRI';

%%%
% 0 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k3_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k3_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k3_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);

%%%
% 3 Refinement

FILE = 'Meshes/Cylinder/Cylinder_TRI_k3_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot Results

figure(1)

loglog(NDOF(1,:),L2_Error(1,:),'b',NDOF(2,:),L2_Error(2,:),'r',NDOF(3,:),L2_Error(3,:),'k')
hold on
rate_1 = L2_Error(1,1).*(0.5*NDOF(1,:)/NDOF(1,1)).^(-2/2);
rate_2 = L2_Error(2,1).*(0.5*NDOF(2,:)/NDOF(2,1)).^(-3/2);
rate_3 = L2_Error(3,1).*(0.5*NDOF(3,:)/NDOF(3,1)).^(-4/2);
loglog(NDOF(1,:),rate_1,'b--.',NDOF(2,:),rate_2,'r--.',NDOF(3,:),rate_3,'k--.')
title('$L^2$-Error for Triangular Meshes: Exact Solution','interpreter','latex','FontSize',16)
xlabel('$NDOF$','interpreter','latex','FontSize',16)
ylabel('$L^2$-Error','interpreter','latex','FontSize',16)
l = legend('$k = 1$','$k = 2$','$k = 3$');
set(l,'interpreter','latex','FontSize',16)

%%%
% Clear Plotting Data

clear NDOF
clear L2_Error

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quadrilateral Study
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1 Study

k = 1;
SHAPE = 'QUAD';

%%%
% 0 Refinement

FILE = 'Meshes/Cylinder/Cylinder_QUAD_k1_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Cylinder/Cylinder_QUAD_k1_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Cylinder/Cylinder_QUAD_k1_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);

%%%
% 3 Refinement

FILE = 'Meshes/Cylinder/Cylinder_QUAD_k1_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2 Study

k = 2;
SHAPE = 'QUAD';

%%%
% 0 Refinement

FILE = 'Meshes/Cylinder/Cylinder_QUAD_k2_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Cylinder/Cylinder_QUAD_k2_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Cylinder/Cylinder_QUAD_k2_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);

%%%
% 3 Refinement

FILE = 'Meshes/Cylinder/Cylinder_QUAD_k2_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot Results

figure(2)

loglog(NDOF(1,:),L2_Error(1,:),'b',NDOF(2,:),L2_Error(2,:))
hold on
rate_1 = L2_Error(1,1).*(0.5*NDOF(1,:)/NDOF(1,1)).^(-2/2);
rate_2 = L2_Error(2,1).*(0.5*NDOF(2,:)/NDOF(2,1)).^(-3/2);
loglog(NDOF(1,:),rate_1,'b--.',NDOF(2,:),rate_2,'r--.')
title('$L^2$-Error for Quadrilateral Meshes: Exact Solution','interpreter','latex','FontSize',16)
xlabel('$NDOF$','interpreter','latex','FontSize',16)
ylabel('$L^2$-Error','interpreter','latex','FontSize',16)
l = legend('$k = 1$','$k = 2$');
set(l,'interpreter','latex','FontSize',16)

%%%
% Clear Plotting Data

clear NDOF
clear L2_Error

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Material Parameter, Loading, and Boundary Condition Functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function kappa = kappa_exact(x,y,i)
    kappa = 385;
end

function f = f_exact(x,y,i)
    f = 0;
end

function g = g_exact(x,y,i)
    switch i
        case 1
            g = 70;
        case 2
            g = 200;
    end
end

function h = h_exact(x,y,i)
    h = 1;
end

function beta = beta_exact(x,y,i)
    beta = 1;
end

function T_R = T_R_exact(x,y,i)
    T_R = 70;
end