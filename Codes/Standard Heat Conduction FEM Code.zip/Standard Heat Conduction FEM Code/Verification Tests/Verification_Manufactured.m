%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Verification Test: Manufactured Solution
%
% Purpose: In this verification test, the FEA code is applied to a problem
%          with a manufactured solution:
%
%                    T(x,y) = sin(x^2)*cos(exp(y)+1)
%
%          The thermal conductivity is set to:
%
%                 kappa(x,y) = exp(x+y)
%
%          and the domain is taken to be a square with Dirichlet boundary
%          conditions set at left and right and Neumann conditions set at
%          top and bottom.  Convergence is assessed for all element types.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Manufactured Solution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_exact = @(x,y) sin(x^2)*cos(exp(y)+1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Material Parameter, Loading, and Boundary Condition Function Handles
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

kappa = @(x,y,i) kappa_manufactured(x,y,i);
f = @(x,y,i) f_manufactured(x,y,i);
g = @(x,y,i) g_manufactured(x,y,i);
h = @(x,y,i) h_manufactured(x,y,i);
beta = @(x,y,i) beta_manufactured(x,y,i);
T_R = @(x,y,i) T_R_manufactured(x,y,i);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Triangular Study
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1 Study

k = 1;
SHAPE = 'TRI';

%%%
% 0 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k1_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k1_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k1_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);

%%%
% 3 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k1_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2 Study

k = 2;
SHAPE = 'TRI';

%%%
% 0 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k2_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k2_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k2_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);


%%%
% 3 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k2_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 3 Study

k = 3;
SHAPE = 'TRI';

%%%
% 0 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k3_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k3_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k3_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);


%%%
% 3 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_TRI_k3_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot Results

figure(1)

loglog(NDOF(1,:),L2_Error(1,:),'b',NDOF(2,:),L2_Error(2,:),'r',NDOF(3,:),L2_Error(3,:),'k')
hold on
rate_1 = L2_Error(1,1).*(0.5*NDOF(1,:)/NDOF(1,1)).^(-2/2);
rate_2 = L2_Error(2,1).*(0.5*NDOF(2,:)/NDOF(2,1)).^(-3/2);
rate_3 = L2_Error(3,1).*(0.5*NDOF(3,:)/NDOF(3,1)).^(-4/2);
loglog(NDOF(1,:),rate_1,'b--.',NDOF(2,:),rate_2,'r--.',NDOF(3,:),rate_3,'k--.')
title('$L^2$-Error for Triangular Meshes: Manufactured Solution','interpreter','latex','FontSize',16)
xlabel('$NDOF$','interpreter','latex','FontSize',16)
ylabel('$L^2$-Error','interpreter','latex','FontSize',16)
l = legend('$k = 1$','$k = 2$','$k = 3$');
set(l,'interpreter','latex','FontSize',16)%%%
% Clear Plotting Data

clear NDOF
clear L2_Error

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quadrilateral Study
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1 Study

k = 1;
SHAPE = 'QUAD';

%%%
% 0 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_QUAD_k1_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_QUAD_k1_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_QUAD_k1_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);

%%%
% 3 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_QUAD_k1_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2 Study

k = 2;
SHAPE = 'QUAD';

%%%
% 0 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_QUAD_k2_r0.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,1)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,1) = size(Nodes,1);

%%%
% 1 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_QUAD_k2_r1.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,2)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,2) = size(Nodes,1);

%%%
% 2 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_QUAD_k2_r2.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,3)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,3) = size(Nodes,1);


%%%
% 3 Refinement

FILE = 'Meshes/Square_Plate/Square_Plate_QUAD_k2_r3.msh';
[IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE);
[Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R);
[L2_Error(k,4)] = Error(SHAPE,k,IEN,Nodes,Temperature,T_exact);
NDOF(k,4) = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot Results

figure(2)

loglog(NDOF(1,:),L2_Error(1,:),'b',NDOF(2,:),L2_Error(2,:))
hold on
rate_1 = L2_Error(1,1).*(0.5*NDOF(1,:)/NDOF(1,1)).^(-2/2);
rate_2 = L2_Error(2,1).*(0.5*NDOF(2,:)/NDOF(2,1)).^(-3/2);
loglog(NDOF(1,:),rate_1,'b--.',NDOF(2,:),rate_2,'r--.')
title('$L^2$-Error for Quadrilateral Meshes: Manufactured Solution','interpreter','latex','FontSize',16)
xlabel('$NDOF$','interpreter','latex','FontSize',16)
ylabel('$L^2$-Error','interpreter','latex','FontSize',16)
l = legend('$k = 1$','$k = 2$');
set(l,'interpreter','latex','FontSize',16)


%%%
% Clear Plotting Data

clear NDOF
clear L2_Error

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Material Parameter, Loading, and Boundary Condition Functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function kappa = kappa_manufactured(x,y,i)
    kappa = exp(x+y);
end

function f = f_manufactured(x,y,i)
    f = sin(x^2)*exp(2*y)*exp(x + y)*cos(exp(y) + 1) - 2*cos(x^2)*exp(x + y)*cos(exp(y) + 1) - 2*x*cos(x^2)*exp(x + y)*cos(exp(y) + 1) + 4*x^2*sin(x^2)*exp(x + y)*cos(exp(y) + 1) + 2*sin(x^2)*exp(x + y)*exp(y)*sin(exp(y) + 1);
end

function g = g_manufactured(x,y,i)
    switch i
        case 1
            g = sin(x^2)*cos(exp(y)+1);
        case 2
            g = sin(x^2)*cos(exp(y)+1);
    end
end

function h = h_manufactured(x,y,i)
    switch i
        case 1
            h = sin(x^2)*exp(x + y)*exp(y)*sin(exp(y) + 1);
        case 2
            h = -sin(x^2)*exp(x + y)*exp(y)*sin(exp(y) + 1);
    end
end

function beta = beta_manufactured(x,y,i)
    beta = 1;
end

function T_R = T_R_manufactured(x,y,i)
    T_R = 70;
end