%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Verification Test: Physical Boundary Element Shape Functions
%
% Purpose: In this verification test, physical boundary element basis
%          functions are computed and plotted.  This allows for 
%          verification by visual inspection.  Only k = 1 and 2 needed.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; clc; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%
% Establish Grid for Plotting

Xi = linspace(-1,1,100);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 1;

B_Nodes(1,1) = 2;
B_Nodes(1,2) = 3;
B_Nodes(2,1) = 6;
B_Nodes(2,2) = 4;

j_analytic = 0.5*sqrt(4^2+1^2);

N = zeros(100,2);

for i = 1:100
    
    [B_Nhat_pt,B_Nhat_xi_pt] = Boundary_Shape_Parent(k,Xi(i));
    [B_N_pt,xb_pt,jb_pt] = Boundary_Shape_Physical(B_Nhat_pt',B_Nhat_xi_pt',B_Nodes);
    
    XB(i) = xb_pt(1);
    YB(i) = xb_pt(2);
    
    for a = 1:2
        B_N(i,a) = B_N_pt(a);
    end
end

%%%
% Basis Function Plot
    
figure(1)

scatter3(XB,YB,B_N(:,1))
hold on
scatter3(XB,YB,B_N(:,2))
plot(XB,YB)
title('Boundary $k = 1$ Basis Functions','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
l = legend('$N_1(\xi)$','$N_2(\xi)$');
set(l,'interpreter','latex','FontSize',16)

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;

B_Nodes(1,1) = 2;
B_Nodes(1,2) = 3;
B_Nodes(2,1) = 6;
B_Nodes(2,2) = 4;
B_Nodes(3,1) = 5;
B_Nodes(3,2) = 5;

N = zeros(100,2);

for i = 1:100
    
    [B_Nhat_pt,B_Nhat_xi_pt] = Boundary_Shape_Parent(k,Xi(i));
    [B_N_pt,xb_pt,jb_pt] = Boundary_Shape_Physical(B_Nhat_pt',B_Nhat_xi_pt',B_Nodes);
    
    XB(i) = xb_pt(1);
    YB(i) = xb_pt(2);
    
    for a = 1:3
        B_N(i,a) = B_N_pt(a);
    end
end

%%%
% Basis Function Plot
    
figure(2)

scatter3(XB,YB,B_N(:,1))
hold on
scatter3(XB,YB,B_N(:,2))
scatter3(XB,YB,B_N(:,3))
plot(XB,YB)
title('Boundary $k = 2$ Basis Functions','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
l = legend('$N_1(\xi)$','$N_2(\xi)$','$N_3(\xi)$');
set(l,'interpreter','latex','FontSize',16)