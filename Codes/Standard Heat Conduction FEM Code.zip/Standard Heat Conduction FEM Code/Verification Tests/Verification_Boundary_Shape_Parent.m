%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Verification Test: Parent Boundary Element Shape Functions
%
% Purpose: In this verification test, parent boundary element shape
%          functions are computed and plotted.  This allows for 
%          verification by visual inspection for degrees k = 1, 2, 3.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%
% Establish Grid for Plotting

Xi = linspace(-1,1,100);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 1;

for i = 1:100
    
    [B_Nhat_pt,B_Nhat_xi_pt] = Boundary_Shape_Parent(k,Xi(i));
    
    for a = 1:k+1
        B_Nhat(i,a) = B_Nhat_pt(a);
        B_Nhat_xi(i,a) = B_Nhat_xi_pt(a);
    end
end

%%%
% Basis Function Plots

figure(1)

plot(Xi,B_Nhat(:,1),Xi,B_Nhat(:,2))
title('Boundary $k = 1$ Basis Functions','interpreter','latex','FontSize',16)
xlabel('$\xi$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
l = legend('$\hat{N}_1(\xi)$','$\hat{N}_2(\xi)$');
set(l,'interpreter','latex','FontSize',16)

figure(2)

plot(Xi,B_Nhat_xi(:,1),Xi,B_Nhat_xi(:,2),Xi,B_Nhat_xi(:,1)+B_Nhat_xi(:,2))
title('Boundary $k = 1$ Basis Function Derivatives','interpreter','latex','FontSize',16)
xlabel('$\xi$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
l = legend('$\hat{N}_{1,x}(\xi)$','$\hat{N}_{2,x}(\xi)$','Sum');
set(l,'interpreter','latex','FontSize',16)

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;

for i = 1:100
    
    [B_Nhat_pt,B_Nhat_xi_pt] = Boundary_Shape_Parent(k,Xi(i));
    
    for a = 1:k+1
        B_Nhat(i,a) = B_Nhat_pt(a);
        B_Nhat_xi(i,a) = B_Nhat_xi_pt(a);
    end
end

%%%
% Basis Function Plots

figure(3)

plot(Xi,B_Nhat(:,1),Xi,B_Nhat(:,2),Xi,B_Nhat(:,3))
title('Boundary $k = 2$ Basis Functions','interpreter','latex','FontSize',16)
xlabel('$\xi$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
l = legend('$\hat{N}_1(\xi)$','$\hat{N}_2(\xi)$','$\hat{N}_3(\xi)$');
set(l,'interpreter','latex','FontSize',16)

figure(4)

plot(Xi,B_Nhat_xi(:,1),Xi,B_Nhat_xi(:,2),Xi,B_Nhat_xi(:,3),Xi,B_Nhat_xi(:,1)+B_Nhat_xi(:,2)+B_Nhat_xi(:,3))
title('Boundary $k = 2$ Basis Function Derivatives','interpreter','latex','FontSize',16)
xlabel('$\xi$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
l = legend('$\hat{N}_{1,x}(\xi)$','$\hat{N}_{2,x}(\xi)$','$\hat{N}_{3,x}(\xi)$','Sum');
set(l,'interpreter','latex','FontSize',16)

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 3
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 3;

for i = 1:100
    
    [B_Nhat_pt,B_Nhat_xi_pt] = Boundary_Shape_Parent(k,Xi(i));
    
    for a = 1:k+1
        B_Nhat(i,a) = B_Nhat_pt(a);
        B_Nhat_xi(i,a) = B_Nhat_xi_pt(a);
    end
end

%%%
% Basis Function Plots

figure(5)

plot(Xi,B_Nhat(:,1),Xi,B_Nhat(:,2),Xi,B_Nhat(:,3),Xi,B_Nhat(:,4))
title('Boundary $k = 3$ Basis Functions','interpreter','latex','FontSize',16)
xlabel('$\xi$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
l = legend('$\hat{N}_1(\xi)$','$\hat{N}_2(\xi)$','$\hat{N}_3(\xi)$','$\hat{N}_4(\xi)$');
set(l,'interpreter','latex','FontSize',16)

figure(6)

plot(Xi,B_Nhat_xi(:,1),Xi,B_Nhat_xi(:,2),Xi,B_Nhat_xi(:,3),Xi,B_Nhat_xi(:,4),Xi,B_Nhat_xi(:,1)+B_Nhat_xi(:,2)+B_Nhat_xi(:,3)+B_Nhat_xi(:,4))
title('Boundary $k = 3$ Basis Function Derivatives','interpreter','latex','FontSize',16)
xlabel('$\xi$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
l = legend('$\hat{N}_{1,x}(\xi)$','$\hat{N}_{2,x}(\xi)$','$\hat{N}_{3,x}(\xi)$','$\hat{N}_{4,x}(\xi)$','Sum');
set(l,'interpreter','latex','FontSize',16)