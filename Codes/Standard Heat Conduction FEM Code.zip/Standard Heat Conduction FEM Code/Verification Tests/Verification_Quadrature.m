%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Verification Test: Quadrature
%
% Purpose: In this verification test, all the implemented quadrature
%          schemes are tested for integrands for which the schemes should
%          be exact.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; clc; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1D Quadrature Verification Tests
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%
% Polynomial Degree k = 1

k = 1;

syms xi;
func = -3*xi^3 + 12*xi^2 - 5*xi + 1;
exact_integral = int(func,-1,1);
clear xi func

func = @(xi) -3*xi^3 + 12*xi^2 - 5*xi + 1;

[B_Quad_Pts,B_Quad_Wts] = Boundary_Quadrature_Data(k);
nq = size(B_Quad_Pts,1);

approximate_integral = 0;
for q = 1:nq
    approximate_integral = approximate_integral + func(B_Quad_Pts(q))*B_Quad_Wts(q);
end

if abs(exact_integral-approximate_integral)/abs(exact_integral) < 1e-10
    fprintf('1D k = 1 quadrature verification test passed.\n')
else
    fprintf('1D k = 1 quadrature verification test failed.\n')
end

%%%
% Polynomial Degree k = 2

k = 2;

syms xi;
func = 5*xi^5 + 4*xi^4 - xi^3 + 2*xi^2 - 10*xi + 2;
exact_integral = int(func,-1,1);
clear xi func

func = @(xi) 5*xi^5 + 4*xi^4 - xi^3 + 2*xi^2 - 10*xi + 2;

[B_Quad_Pts,B_Quad_Wts] = Boundary_Quadrature_Data(k);
nq = size(B_Quad_Pts,1);

approximate_integral = 0;
for q = 1:nq
    approximate_integral = approximate_integral + func(B_Quad_Pts(q))*B_Quad_Wts(q);
end

if abs(exact_integral-approximate_integral)/abs(exact_integral) < 1e-10
    fprintf('1D k = 2 quadrature verification test passed.\n')
else
    fprintf('1D k = 2 quadrature verification test failed.\n')
end

%%%
% Polynomial Degree k = 3

k = 3;

syms xi;
func = -7*xi^7 + 2*xi^6 - 3*xi^5 + 2*xi^4 - 14*xi^3 + 2*xi^2 + 3*xi + 3;
exact_integral = int(func,-1,1);
clear xi func

func = @(xi) -7*xi^7 + 2*xi^6 - 3*xi^5 + 2*xi^4 - 14*xi^3 + 2*xi^2 + 3*xi + 3;

[B_Quad_Pts,B_Quad_Wts] = Boundary_Quadrature_Data(k);
nq = size(B_Quad_Pts,1);

approximate_integral = 0;
for q = 1:nq
    approximate_integral = approximate_integral + func(B_Quad_Pts(q))*B_Quad_Wts(q);
end

if abs(exact_integral-approximate_integral)/abs(exact_integral) < 1e-10
    fprintf('1D k = 3 quadrature verification test passed.\n')
else
    fprintf('1D k = 3 quadrature verification test failed.\n')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Triangle Quadrature Verification Tests
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SHAPE = 'TRI';

%%%
% Polynomial Degree k = 1

k = 1;

syms xi_1 xi_2;
func = xi_1^2 - xi_2^2 + 3*xi_1 + 2*xi_2 - 3;
exact_integral = int(int(func,0,1-xi_2),0,1);
clear xi func

func = @(xi_1,xi_2) xi_1^2 - xi_2^2 + 3*xi_1 + 2*xi_2 - 3;

[Quad_Pts,Quad_Wts] = Quadrature_Data(SHAPE,k);

nq = size(Quad_Pts,1);

approximate_integral = 0;
for q = 1:nq
    approximate_integral = approximate_integral + func(Quad_Pts(q,1),Quad_Pts(q,2))*Quad_Wts(q);
end

if abs(exact_integral-approximate_integral)/abs(exact_integral) < 1e-10
    fprintf('TRI k = 1 quadrature verification test passed.\n')
else
    fprintf('TRI k = 1 quadrature verification test failed.\n')
end

%%%
% Polynomial Degree k = 2

k = 2;

syms xi_1 xi_2;
func =  4*xi_1^4 - 3*xi_1^3*xi_2 + 2*xi_1^2*xi_2^2 - 3*xi_1*xi_2^3 + 4*xi_2^4 + 3*xi_1^3 - 2*xi_1^2*xi_2 + 2*xi_1*xi_2^2 - 3*xi_2^3 + xi_1^2 - xi_2^2 + 3*xi_1 + 2*xi_2 - 3;
exact_integral = int(int(func,0,1-xi_2),0,1);
clear xi func

func = @(xi_1,xi_2) 4*xi_1^4 - 3*xi_1^3*xi_2 + 2*xi_1^2*xi_2^2 - 3*xi_1*xi_2^3 + 4*xi_2^4 + 3*xi_1^3 - 2*xi_1^2*xi_2 + 2*xi_1*xi_2^2 - 3*xi_2^3 + xi_1^2 - xi_2^2 + 3*xi_1 + 2*xi_2 - 3;

[Quad_Pts,Quad_Wts] = Quadrature_Data(SHAPE,k);

nq = size(Quad_Pts,1);

approximate_integral = 0;
for q = 1:nq
    approximate_integral = approximate_integral + func(Quad_Pts(q,1),Quad_Pts(q,2))*Quad_Wts(q);
end

if abs(exact_integral-approximate_integral)/abs(exact_integral) < 1e-10
    fprintf('TRI k = 2 quadrature verification test passed.\n')
else
    fprintf('TRI k = 2 quadrature verification test failed.\n')
end

%%%
% Polynomial Degree k = 3

k = 3;

syms xi_1 xi_2;
func = 6*xi_1^4*xi_2^2 - 5*xi_1^2*xi_2^3 + 4*xi_1^4 - 3*xi_1^3*xi_2 + 2*xi_1^2*xi_2^2 - 3*xi_1*xi_2^3 + 4*xi_2^4 + 3*xi_1^3 - 2*xi_1^2*xi_2 + 2*xi_1*xi_2^2 - 3*xi_2^3 + xi_1^2 - xi_2^2 + 3*xi_1 + 2*xi_2 - 3;
exact_integral = int(int(func,0,1-xi_2),0,1);
clear xi func

func = @(xi_1,xi_2) 6*xi_1^4*xi_2^2 - 5*xi_1^2*xi_2^3 + 4*xi_1^4 - 3*xi_1^3*xi_2 + 2*xi_1^2*xi_2^2 - 3*xi_1*xi_2^3 + 4*xi_2^4 + 3*xi_1^3 - 2*xi_1^2*xi_2 + 2*xi_1*xi_2^2 - 3*xi_2^3 + xi_1^2 - xi_2^2 + 3*xi_1 + 2*xi_2 - 3;

[Quad_Pts,Quad_Wts] = Quadrature_Data(SHAPE,k);

nq = size(Quad_Pts,1);

approximate_integral = 0;
for q = 1:nq
    approximate_integral = approximate_integral + func(Quad_Pts(q,1),Quad_Pts(q,2))*Quad_Wts(q);
end

if abs(exact_integral-approximate_integral)/abs(exact_integral) < 1e-10
    fprintf('TRI k = 3 quadrature verification test passed.\n')
else
    fprintf('TRI k = 3 quadrature verification test failed.\n')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quadrilateral Quadrature Verification Tests
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SHAPE = 'QUAD';

%%%
% Polynomial Degree k = 1

k = 1;

syms xi_1 xi_2;
func = 3*xi_1^3*xi_2^3 + 2*xi_1*xi_2^3 - 2*2*xi_1^2*xi_2 + 5*xi_2^2 + 3*xi_1 - 10;
exact_integral = int(int(func,-1,1),-1,1);
clear xi func

func = @(xi_1,xi_2) 3*xi_1^3*xi_2^3 + 2*xi_1*xi_2^3 - 2*2*xi_1^2*xi_2 + 5*xi_2^2 + 3*xi_1 - 10;

[Quad_Pts,Quad_Wts] = Quadrature_Data(SHAPE,k);

nq = size(Quad_Pts,1);

approximate_integral = 0;
for q = 1:nq
    approximate_integral = approximate_integral + func(Quad_Pts(q,1),Quad_Pts(q,2))*Quad_Wts(q);
end

if abs(exact_integral-approximate_integral)/abs(exact_integral) < 1e-10
    fprintf('QUAD k = 1 quadrature verification test passed.\n')
else
    fprintf('QUAD k = 1 quadrature verification test failed.\n')
end

%%%
% Polynomial Degree k = 2

k = 2;

syms xi_1 xi_2;
func = 5*xi_1^5*xi_2^5 + 4*xi_1^4*xi_2 - 3*xi_1^3*xi_2^4 - 2*xi_1^2*xi_2^3 + 2*xi_1*xi_2^3 - 2*2*xi_1^2*xi_2 + 5*xi_2^2 + 3*xi_1 - 10;
exact_integral = int(int(func,-1,1),-1,1);
clear xi func

func = @(xi_1,xi_2) 5*xi_1^5*xi_2^5 + 4*xi_1^4*xi_2 - 3*xi_1^3*xi_2^4 - 2*xi_1^2*xi_2^3 + 2*xi_1*xi_2^3 - 2*2*xi_1^2*xi_2 + 5*xi_2^2 + 3*xi_1 - 10;

[Quad_Pts,Quad_Wts] = Quadrature_Data(SHAPE,k);

nq = size(Quad_Pts,1);

approximate_integral = 0;
for q = 1:nq
    approximate_integral = approximate_integral + func(Quad_Pts(q,1),Quad_Pts(q,2))*Quad_Wts(q);
end

if abs(exact_integral-approximate_integral)/abs(exact_integral) < 1e-10
    fprintf('QUAD k = 2 quadrature verification test passed.\n')
else
    fprintf('QUAD k = 2 quadrature verification test failed.\n')
end