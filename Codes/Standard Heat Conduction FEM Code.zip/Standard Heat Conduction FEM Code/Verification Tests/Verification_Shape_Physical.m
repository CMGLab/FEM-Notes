%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Verification Test: Physical Element Shape Functions
%
% Purpose: In this verification test, physical element basis functions are
%          are computed and plotted.  This allows for verification by
%          visual inspection.  Only triangular elements of degree k = 1,2
%          are tested as the involved scripts are generic.  Additionally,
%          the script confirms basis functions sum to one and their 
%          derivatives sum to zero.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; clc; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Triangular Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%
% Establish Grid for Calculating

[Xi_1_pre,Xi_2_pre] = meshgrid(linspace(0,1,20),linspace(0,1,20));

Xi_1_pre = reshape(Xi_1_pre,[400,1]);
Xi_2_pre = reshape(Xi_2_pre,[400,1]);

n = 0;

for i = 1:400
    xi_1 = Xi_1_pre(i);
    xi_2 = Xi_2_pre(i);
    
    if xi_1 + xi_2 <= 1
        n = n+1;
        Xi_1(n) = xi_1;
        Xi_2(n) = xi_2;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 1;

Nodes(1,1) = 0;
Nodes(1,2) = 0;
Nodes(2,1) = 10;
Nodes(2,2) = 1;
Nodes(3,1) = 3;
Nodes(3,2) = 4;

j_analytic = Nodes(1,1)*(Nodes(2,2)-Nodes(3,2)) + Nodes(3,1)*(Nodes(1,2)-Nodes(2,2)) + Nodes(2,1)*(Nodes(3,2)-Nodes(1,2));

N = zeros(n,3);

val_ver_test = 0;
der_ver_test = 0;

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    [N_pt,N_x_pt,x_pt,j_pt] = Shape_Physical(Nhat_pt',Nhat_xi_pt,Nodes);
    
    if abs(sum(N_pt) - 1) >= 1e-10
        val_ver_test = 1;
    end
    
    if abs(sum(N_x_pt)) >= 1e-10
        der_ver_test = 1;
    end
    
    X(i) = x_pt(1);
    Y(i) = x_pt(2);
    
    for a = 1:3
        N(i,a) = N_pt(a);
    end
end

%%%
% Results of Verification Tests

if val_ver_test == 0
    fprintf('TRI k = 1 basis function verification test passed.\n')
else
    cprintf('_red','TRI k = 1 basis function verification test failed!\n')
end

if der_ver_test == 0
    fprintf('TRI k = 1 derivative verification test passed.\n')
else
    cprintf('_red','TRI k = 1 derivative verification test failed!\n')
end

if abs(j_analytic - j_pt) < 1e-10
    fprintf('TRI k = 1 determinant computed correctly.\n')
else
    cprintf('_red','TRI k = 1 determinant computed incorrectly!\n')
end


%%%
% Basis Function Plots
    
figure(1)

scatter3(X,Y,N(:,1))
hold on
for a = 1:3
    if a == 1
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 1$: $N_1(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(2)

scatter3(X,Y,N(:,2))
hold on
for a = 1:3
    if a == 2
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 1$: $N_2(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(3)

scatter3(X,Y,N(:,3))
hold on
for a = 1:3
    if a == 3
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 1$: $N_3(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;

Nodes(1,1) = 0;
Nodes(1,2) = 0;
Nodes(2,1) = 10;
Nodes(2,2) = 1;
Nodes(3,1) = 3;
Nodes(3,2) = 4;
Nodes(4,1) = 4;
Nodes(4,2) = -1;
Nodes(5,1) = 6;
Nodes(5,2) = 4;
Nodes(6,1) = 2;
Nodes(6,2) = 2;

N = zeros(n,6);

val_ver_test = 0;
der_ver_test = 0;

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    [N_pt,N_x_pt,x_pt,j_pt] = Shape_Physical(Nhat_pt',Nhat_xi_pt,Nodes);
    
    if abs(sum(N_pt) - 1) >= 1e-10
        val_ver_test = 1;
    end
    
    if abs(sum(N_x_pt)) >= 1e-10
        der_ver_test = 1;
    end
    
    X(i) = x_pt(1);
    Y(i) = x_pt(2);
    
    for j = 1:6
        N(i,j) = N_pt(j);
    end
end

%%%
% Results of Verification Tests

if val_ver_test == 0
    fprintf('TRI k = 2 basis function verification test passed.\n')
else
    cprintf('_red','TRI k = 2 basis function verification test failed!\n')
end

if der_ver_test == 0
    fprintf('TRI k = 2 derivative verification test passed.\n')
else
    cprintf('_red','TRI k = 2 derivative verification test failed!\n')
end

%%%
% Basis Function Plots
    
figure(4)

scatter3(X,Y,N(:,1))
hold on
for a = 1:6
    if a == 1
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_1(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(5)

scatter3(X,Y,N(:,2))
hold on
for a = 1:6
    if a == 2
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_2(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(6)

scatter3(X,Y,N(:,3))
hold on
for a = 1:6
    if a == 3
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_3(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(7)

scatter3(X,Y,N(:,4))
hold on
for a = 1:6
    if a == 4
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_4(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(8)

scatter3(X,Y,N(:,5))
hold on
for a = 1:6
    if a == 5
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_5(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)

figure(9)

scatter3(X,Y,N(:,6))
hold on
for a = 1:6
    if a == 6
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_6(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)