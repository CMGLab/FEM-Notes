%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Error
%
% Input:  SHAPE = element shape (TRI or QUAD)
%         k = polynomial degree (1,2,3 for TRI, 1,2 for QUAD)
%         IEN = element connectivity array
%         Nodes = node array
%         T_discrete = finite element temperature values at nodes
%         T_exac = exact temperature function handle
%
% Output: L2_Error = L2 error of finite element approximation
%
% Purpose: Compute L2 error of finite element approximation
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [L2_Error] = Error(SHAPE,k,IEN,Nodes,T_discrete,T_exact)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nen = size(IEN,1);
nel = size(IEN,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Identify quadrature points and weights

[Quad_Pts,Quad_Wts] = Quadrature_Data(SHAPE,k);
nq = size(Quad_Wts,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Precompute shape functions at quadrature points

[Nhat,Nhat_xi] = Precompute_Shape(SHAPE,k,Quad_Pts);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute L2 error of finite element approximation

%%%
% Initialize error

L2_Error = 0;

%%%
% Loop over elements
for e = 1:nel

    %%%
    % Loop over quadrature points
    for l = 1:nq

        %%%
        % Compute basis function values, position, and Jacobian
        [N,~,x,j] = Shape_Physical(Nhat(:,l),Nhat_xi(:,:,l),Nodes(IEN(:,e),:));

        %%%
        % Compute exact temperature at point
        T_exact_loc = T_exact(x(1),x(2));
        
        %%%
        % Compute discrete temperature at point
        T_discrete_loc = 0;
        for a = 1:nen
            T_discrete_loc = T_discrete_loc + T_discrete(IEN(a,e))*N(a);
        end

        %%%
        % Compute contribution to square of L2 error
        L2_Error = L2_Error + (T_exact_loc - T_discrete_loc)^2*Quad_Wts(l)*j;
    end
end

%%%
% Take a square root
L2_Error = sqrt(L2_Error);