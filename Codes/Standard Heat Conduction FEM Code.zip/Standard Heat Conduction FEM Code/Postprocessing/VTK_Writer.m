%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: VTK_Writer
%
% Input:  FILE = name of file to write
%         SHAPE = element shape (TRI or QUAD)
%         IEN = element connectivity array
%         Nodes = node array
%         Temperature = value of temperature at nodes
%
% Purpose: Write VTK file with finite element temperature field
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function VTK_Writer(FILE,SHAPE,IEN,Nodes,Temperature)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nen = size(IEN,1);
nel = size(IEN,2);
nnod = size(Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set precision

precision = '15';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Open file for writing

fid = fopen(FILE, 'w');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Write preamble

fprintf(fid, '# vtk DataFile Version 2.0\n');
fprintf(fid, 'VTK from ASEN 5007 FEA Code\n');
fprintf(fid, 'ASCII\n');
fprintf(fid, 'DATASET UNSTRUCTURED_GRID\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Write node array

fprintf(fid, ['POINTS ' num2str(nnod) ' float\n']);

spec = ['%0.', precision, 'f '];

for i = 1:nnod
    output = [Nodes(i,:) 0]';
    fprintf(fid, spec, output);
    fprintf(fid, '\n');
end

fprintf(fid, '\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Write element connectivity array

fprintf(fid, ['CELLS ' num2str(nel) ' ' num2str((nen+1)*nel) '\n']);

spec = ['%d '];

for i = 1:nel
    output = [nen (IEN(:,i)-1)']';
    fprintf(fid, spec, output);
    fprintf(fid, '\n');
end

fprintf(fid, '\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Write element types

fprintf(fid, ['CELL_TYPES ' num2str(nel) '\n']);

spec = ['%d '];

if strcmp(SHAPE,'TRI')
    shape = 69;
else
    shape = 70;
end

for i = 1:nel
    output = [shape];
    fprintf(fid, spec, output);
    fprintf(fid, '\n');
end

fprintf(fid, '\n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Write finite element temperature at nodes

fprintf(fid, ['POINT_DATA ' num2str(nnod) '\n']);
fprintf(fid, ['SCALARS Temperature float 1\n']);
fprintf(fid, ['LOOKUP_TABLE default\n']);

spec = ['%0.', precision, 'f '];

for i = 1:nnod
    output = [Temperature(i)];
    fprintf(fid, spec, output);
    fprintf(fid, '\n');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Close file

fclose(fid);