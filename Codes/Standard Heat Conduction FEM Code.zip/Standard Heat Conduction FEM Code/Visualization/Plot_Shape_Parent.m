%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Plot Parent Element Shape Functions
%
% Purpose: In this scipt, parent element shape functions are plotted.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear all; clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Triangular Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%
% Establish Grid for Plotting

[Xi_1_pre,Xi_2_pre] = meshgrid(linspace(0,1,50),linspace(0,1,50));

Xi_1_pre = reshape(Xi_1_pre,[2500,1]);
Xi_2_pre = reshape(Xi_2_pre,[2500,1]);

n = 0;

for i = 1:2500
    xi_1 = Xi_1_pre(i);
    xi_2 = Xi_2_pre(i);
    
    if xi_1 + xi_2 <= 1
        n = n+1;
        Xi_1(n) = xi_1;
        Xi_2(n) = xi_2;
    end
end

DT = delaunay(Xi_1,Xi_2);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 1;
Nhat = zeros(n,3);

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    
    for j = 1:3
        Nhat(i,j) = Nhat_pt(j);
    end
end

%%%
% Basis Function Plots
    
figure(1)

trisurf(DT,Xi_1,Xi_2,Nhat(:,1))
shading interp
hold on
scatter3(0,0,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
title('TRI $k = 1$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k1_N1.png')

figure(2)

trisurf(DT,Xi_1,Xi_2,Nhat(:,2))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
title('TRI $k = 1$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k1_N2.png')

figure(3)

trisurf(DT,Xi_1,Xi_2,Nhat(:,3))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
title('TRI $k = 1$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k1_N3.png')

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;
Nhat = zeros(n,6);

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    
    for j = 1:6
        Nhat(i,j) = Nhat_pt(j);
    end
end

%%%
% Basis Function Plots

figure(4)

trisurf(DT,Xi_1,Xi_2,Nhat(:,1))
shading interp
hold on
scatter3(0,0,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N1.png')

figure(5)

trisurf(DT,Xi_1,Xi_2,Nhat(:,2))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N2.png')

figure(6)

trisurf(DT,Xi_1,Xi_2,Nhat(:,3))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N3.png')

figure(7)

trisurf(DT,Xi_1,Xi_2,Nhat(:,4))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0.5,0,1,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N4.png')

figure(8)

trisurf(DT,Xi_1,Xi_2,Nhat(:,5))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,1,50,'k*')
scatter3(0,0.5,0,50,'k*')
title('TRI $k = 2$: $\hat{N}_5(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N5.png')

figure(9)

trisurf(DT,Xi_1,Xi_2,Nhat(:,6))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0.5,0,0,50,'k*')
scatter3(0.5,0.5,0,50,'k*')
scatter3(0,0.5,1,50,'k*')
title('TRI $k = 2$: $\hat{N}_6(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N6.png')

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 3
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 3;
Nhat = zeros(n,10);

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    
    if abs(sum(Nhat_pt) - 1) >= 1e-10
        val_ver_test = 1;
    end
    
    if abs(sum(Nhat_xi_pt)) >= 1e-10
        der_ver_test = 1;
    end
    
    for j = 1:10
        Nhat(i,j) = Nhat_pt(j);
    end
end

%%%
% Basis Function Plots

figure(10)

trisurf(DT,Xi_1,Xi_2,Nhat(:,1))
shading interp
hold on
scatter3(0,0,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N1.png')

figure(11)

trisurf(DT,Xi_1,Xi_2,Nhat(:,2))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N2.png')

figure(12)

trisurf(DT,Xi_1,Xi_2,Nhat(:,3))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N3.png')

figure(13)

trisurf(DT,Xi_1,Xi_2,Nhat(:,4))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,1,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N4.png')

figure(14)

trisurf(DT,Xi_1,Xi_2,Nhat(:,5))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,1,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_5(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N5.png')

figure(15)

trisurf(DT,Xi_1,Xi_2,Nhat(:,6))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,1,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_6(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N6.png')

figure(16)

trisurf(DT,Xi_1,Xi_2,Nhat(:,7))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,1,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_7(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N7.png')

figure(17)

trisurf(DT,Xi_1,Xi_2,Nhat(:,8))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,1,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_8(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N8.png')

figure(18)

trisurf(DT,Xi_1,Xi_2,Nhat(:,9))
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,1,50,'k*')
scatter3(1/3,1/3,0,50,'k*')
title('TRI $k = 3$: $\hat{N}_9(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N9.png')

figure(19)

trisurf(DT,Xi_1,Xi_2,Nhat(:,10));
shading interp
hold on
scatter3(0,0,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(1/3,0,0,50,'k*')
scatter3(2/3,0,0,50,'k*')
scatter3(2/3,1/3,0,50,'k*')
scatter3(1/3,2/3,0,50,'k*')
scatter3(0,2/3,0,50,'k*')
scatter3(0,1/3,0,50,'k*')
scatter3(1/3,1/3,1,50,'k*')
title('TRI $k = 3$: $\hat{N}_{10}(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k3_N10.png')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quadrilateral Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%
% Establish Grid for Plotting

[Xi_1,Xi_2] = meshgrid(linspace(-1,1,50),linspace(-1,1,50));

n = 50;

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 1
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 1;
Nhat = zeros(n,n,4);

for i = 1:n
    for j = 1:n
        xi_1 = Xi_1(i,j);
        xi_2 = Xi_2(i,j);
    
        [Nhat_pt,Nhat_xi_pt] = Shape_Parent('QUAD',k,xi_1,xi_2);
    
        for l = 1:4
            Nhat(i,j,l) = Nhat_pt(l);
        end
    end
end

%%%
% Basis Function Plots

figure(20)

surf(Xi_1,Xi_2,Nhat(:,:,1))
shading interp
hold on
scatter3(-1,-1,1,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
title('QUAD $k = 1$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'QUAD_k1_N1.png')

figure(21)

surf(Xi_1,Xi_2,Nhat(:,:,2))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,1,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
title('QUAD $k = 1$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'QUAD_k1_N2.png')

figure(22)

surf(Xi_1,Xi_2,Nhat(:,:,3))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,1,50,'k*')
scatter3(-1,1,0,50,'k*')
title('QUAD $k = 1$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'QUAD_k1_N3.png')

figure(23)

surf(Xi_1,Xi_2,Nhat(:,:,4))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,1,50,'k*')
title('QUAD $k = 1$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'QUAD_k1_N4.png')

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%     Tensor Product
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;
Nhat = zeros(n,9);

for i = 1:n
    for j = 1:n
        xi_1 = Xi_1(i,j);
        xi_2 = Xi_2(i,j);
    
        [Nhat_pt,Nhat_xi_pt] = Shape_Parent('QUAD',k,xi_1,xi_2);
    
        for l = 1:9
            Nhat(i,j,l) = Nhat_pt(l);
        end
    end
end

%%%
% Basis Function Plots

figure(24)

surf(Xi_1,Xi_2,Nhat(:,:,1))
shading interp
hold on
scatter3(-1,-1,1,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N1.png')

figure(25)

surf(Xi_1,Xi_2,Nhat(:,:,2))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,1,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N2.png')

figure(26)

surf(Xi_1,Xi_2,Nhat(:,:,3))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,1,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N3.png')

figure(27)

surf(Xi_1,Xi_2,Nhat(:,:,4))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,1,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N4.png')

figure(28)

surf(Xi_1,Xi_2,Nhat(:,:,5))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_5(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N5.png')

figure(29)

surf(Xi_1,Xi_2,Nhat(:,:,6))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_6(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N6.png')

figure(30)

surf(Xi_1,Xi_2,Nhat(:,:,7))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,0,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_7(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N7.png')

figure(31)

surf(Xi_1,Xi_2,Nhat(:,:,8))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,1,50,'k*')
scatter3(0,0,0,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_8(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N8.png')

figure(32)

surf(Xi_1,Xi_2,Nhat(:,:,9))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
scatter3(0,0,1,50,'k*')
title('TENSOR PROD QUAD $k = 2$: $\hat{N}_9(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TENSOR_PROD_QUAD_k2_N9.png')

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%      Serendipity
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;
Nhat = zeros(n,8);

for i = 1:n
    for j = 1:n
        xi_1 = Xi_1(i,j);
        xi_2 = Xi_2(i,j);
    
        Nhat(i,j,1) = 0.25*(1-xi_1)*(1-xi_2)*(-xi_2-xi_1-1);
        Nhat(i,j,2) = 0.25*(1+xi_1)*(1-xi_2)*(-xi_2+xi_1-1);
        Nhat(i,j,3) = 0.25*(1+xi_1)*(1+xi_2)*(xi_2+xi_1-1);
        Nhat(i,j,4) = 0.25*(1-xi_1)*(1+xi_2)*(xi_2-xi_1-1);
        Nhat(i,j,5) = 0.5*(1-xi_1^2)*(1-xi_2);
        Nhat(i,j,6) = 0.5*(1-xi_2^2)*(1+xi_1);
        Nhat(i,j,7) = 0.5*(1-xi_1^2)*(1+xi_2);
        Nhat(i,j,8) = 0.5*(1-xi_2^2)*(1-xi_1);
    end
end

%%%
% Basis Function Plots

figure(33)

surf(Xi_1,Xi_2,Nhat(:,:,1))
shading interp
hold on
scatter3(-1,-1,1,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
title('SERENDIPITY QUAD $k = 2$: $\hat{N}_1(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'SERENDIPITY_QUAD_k2_N1.png')

figure(34)

surf(Xi_1,Xi_2,Nhat(:,:,2))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,1,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
title('SERENDIPITY QUAD $k = 2$: $\hat{N}_2(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'SERENDIPITY_QUAD_k2_N2.png')

figure(35)

surf(Xi_1,Xi_2,Nhat(:,:,3))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,1,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
title('SERENDIPITY QUAD $k = 2$: $\hat{N}_3(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'SERENDIPITY_QUAD_k2_N3.png')

figure(36)

surf(Xi_1,Xi_2,Nhat(:,:,4))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,1,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
title('SERENDIPITY QUAD $k = 2$: $\hat{N}_4(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'SERENDIPITY_QUAD_k2_N4.png')

figure(37)

surf(Xi_1,Xi_2,Nhat(:,:,5))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,1,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
title('SERENDIPITY QUAD $k = 2$: $\hat{N}_5(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'SERENDIPITY_QUAD_k2_N5.png')

figure(38)

surf(Xi_1,Xi_2,Nhat(:,:,6))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,1,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,0,50,'k*')
title('SERENDIPITY QUAD $k = 2$: $\hat{N}_6(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'SERENDIPITY_QUAD_k2_N6.png')

figure(39)

surf(Xi_1,Xi_2,Nhat(:,:,7))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,1,50,'k*')
scatter3(-1,0,0,50,'k*')
title('SERENDIPITY QUAD $k = 2$: $\hat{N}_7(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'SERENDIPITY_QUAD_k2_N7.png')

figure(40)

surf(Xi_1,Xi_2,Nhat(:,:,8))
shading interp
hold on
scatter3(-1,-1,0,50,'k*')
scatter3(1,-1,0,50,'k*')
scatter3(1,1,0,50,'k*')
scatter3(-1,1,0,50,'k*')
scatter3(0,-1,0,50,'k*')
scatter3(1,0,0,50,'k*')
scatter3(0,1,0,50,'k*')
scatter3(-1,0,1,50,'k*')
title('SERENDIPITY QUAD $k = 2$: $\hat{N}_8(\xi_1,\xi_2)$','interpreter','latex','FontSize',16)
xlabel('$\xi_1$','interpreter','latex','FontSize',16)
ylabel('$\xi_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'SERENDIPITY_QUAD_k2_N8.png')