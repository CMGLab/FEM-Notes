%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Plot Physical Element Shape Functions
%
% Purpose: In this scipt, physical element shape functions are plotted.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; clc; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add Preprocessing, Processing, and Postprocessing Directories to Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('../Preprocessing/');
addpath('../Processing/');
addpath('../Postprocessing/');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Triangular Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%
% Establish Grid for Calculating

[Xi_1_pre,Xi_2_pre] = meshgrid(linspace(0,1,50),linspace(0,1,50));

Xi_1_pre = reshape(Xi_1_pre,[2500,1]);
Xi_2_pre = reshape(Xi_2_pre,[2500,1]);

n = 0;

for i = 1:2500
    xi_1 = Xi_1_pre(i);
    xi_2 = Xi_2_pre(i);
    
    if xi_1 + xi_2 <= 1
        n = n+1;
        Xi_1(n) = xi_1;
        Xi_2(n) = xi_2;
    end
end

DT = delaunay(Xi_1,Xi_2);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Polynomial Degree k = 2
%%%%%%%%%%%%%%%%%%%%%%%%%%

k = 2;

Nodes(1,1) = 0;
Nodes(1,2) = 0;
Nodes(2,1) = 10;
Nodes(2,2) = 1;
Nodes(3,1) = 3;
Nodes(3,2) = 4;
Nodes(4,1) = 4;
Nodes(4,2) = -1;
Nodes(5,1) = 6;
Nodes(5,2) = 4;
Nodes(6,1) = 2;
Nodes(6,2) = 2;

N = zeros(n,6);

for i = 1:n
    xi_1 = Xi_1(i);
    xi_2 = Xi_2(i);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent('TRI',k,xi_1,xi_2);
    [N_pt,N_x_pt,x_pt,j_pt] = Shape_Physical(Nhat_pt',Nhat_xi_pt,Nodes);    
    
    X(i) = x_pt(1);
    Y(i) = x_pt(2);
    
    for j = 1:6
        N(i,j) = N_pt(j);
    end
end

%%%
% Basis Function Plots
    
figure(1)

trisurf(DT,X,Y,N(:,1))
shading interp
hold on
for a = 1:6
    if a == 1
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_1(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N1_phys.png')

figure(2)

trisurf(DT,X,Y,N(:,2))
shading interp
hold on
for a = 1:6
    if a == 2
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_2(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N2_phys.png')

figure(3)

trisurf(DT,X,Y,N(:,3))
shading interp
hold on
for a = 1:6
    if a == 3
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_3(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N3_phys.png')

figure(4)

trisurf(DT,X,Y,N(:,4))
shading interp
hold on
for a = 1:6
    if a == 4
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_4(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N4_phys.png')

figure(5)

trisurf(DT,X,Y,N(:,5))
shading interp
hold on
for a = 1:6
    if a == 5
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_5(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N5_phys.png')

figure(6)

trisurf(DT,X,Y,N(:,6))
shading interp
hold on
for a = 1:6
    if a == 6
        scatter3(Nodes(a,1),Nodes(a,2),1,50,'k*')
    else
        scatter3(Nodes(a,1),Nodes(a,2),0,50,'k*')
    end
end
title('TRI $k = 2$: $N_6(x_1,x_2)$','interpreter','latex','FontSize',16)
xlabel('$x_1$','interpreter','latex','FontSize',16)
ylabel('$x_2$','interpreter','latex','FontSize',16)
set(gca,'FontName','Times','FontSize',14)
saveas(gcf,'TRI_k2_N6_phys.png')