%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Boundary_Quadrature_Data
%
% Input:  k = polynomial degree         
%
% Output: B_Quad_Pts = parent boundary element quadrature points
%         B_Quad_Wts = parent boundary element quadrature weights
%
% Purpose: Compute parent boundary element quadrature points and weights
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [B_Quad_Pts,B_Quad_Wts] = Boundary_Quadrature_Data(k)

switch k
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Polynomial Degree k = 1
    %
    case 1
        
        B_Quad_Pts = [1/sqrt(3); -1/sqrt(3)];
        B_Quad_Wts = [1; 1];
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Polynomial Degree k = 2
    %
    case 2
        
        B_Quad_Pts = [0; sqrt(3/5); -sqrt(3/5)];
        B_Quad_Wts = [8/9; 5/9; 5/9];
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Polynomial Degree k = 3
    %
    case 3
        
        B_Quad_Pts = [sqrt(3/7 - 2/7*sqrt(6/5)); -sqrt(3/7 - 2/7*sqrt(6/5)); sqrt(3/7 + 2/7*sqrt(6/5)); -sqrt(3/7 + 2/7*sqrt(6/5))];
        B_Quad_Wts = [(18+sqrt(30))/36; (18+sqrt(30))/36; (18-sqrt(30))/36; (18-sqrt(30))/36];
end
