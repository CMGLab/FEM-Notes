%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Precompute_Shape
%
% Input:  SHAPE = element shape (TRI or QUAD)
%         k = polynomial degree (1,2,3 for TRI, 1,2 for QUAD)
%         Quad_Pts = parent element quadrature points
%
% Output: Nhat = parent element shape function values
%         Nhat_xi = parent element shape function derivatives
%
% Purpose: Compute parent element shape function values and derivatives
%          at all quadrature points
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Nhat,Nhat_xi] = Precompute_Shape(SHAPE,k,Quad_Pts)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nq = size(Quad_Pts,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop over parent element quadrature points

for l = 1:nq
    xi_1 = Quad_Pts(l,1);
    xi_2 = Quad_Pts(l,2);
    
    [Nhat_pt,Nhat_xi_pt] = Shape_Parent(SHAPE,k,xi_1,xi_2);
    
    Nhat(:,l) = Nhat_pt;
    Nhat_xi(:,:,l) = Nhat_xi_pt;
end