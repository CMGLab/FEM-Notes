%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Shape_Parent
%
% Input:  SHAPE = element shape (TRI or QUAD)
%         k = polynomial degree (1,2,3 for TRI, 1,2 for QUAD)
%         xi_1 = xi_1-location on parent element
%         xi_2 = xi_2-location on parent element
%
% Output: Nhat = parent element shape function values
%         Nhat_xi = parent element shape function derivatives
%
% Purpose: Compute parent element shape function values and derivatives
%          at single point
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Nhat,Nhat_xi] = Shape_Parent(SHAPE,k,xi_1,xi_2)

switch SHAPE
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %               Triangular Finite Elements
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    case 'TRI'
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Barycentric Coordinates

        lambda_1 = 1-(xi_1+xi_2);
        lambda_2 = xi_1;
        lambda_3 = xi_2;
        
        lambda_1_xi(1) = -1;
        lambda_1_xi(2) = -1;
        
        lambda_2_xi(1) = 1;
        lambda_2_xi(2) = 0;
        
        lambda_3_xi(1) = 0;
        lambda_3_xi(2) = 1;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Shape Function Computations
        
        switch k
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % Polynomial Degree k = 1
            %
            %   3
            %   |\
            %   | \
            %   |  \
            %   |   \
            %   |    \
            %   |     \
            %   |      \
            %   1-------2
            %
            case 1
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Functions
                %
                Nhat(1) = lambda_1;
                Nhat(2) = lambda_2;
                Nhat(3) = lambda_3;
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Derivatives
                %
                Nhat_xi(1,1) = lambda_1_xi(1);
                Nhat_xi(1,2) = lambda_1_xi(2);
                Nhat_xi(2,1) = lambda_2_xi(1);
                Nhat_xi(2,2) = lambda_2_xi(2);
                Nhat_xi(3,1) = lambda_3_xi(1);
                Nhat_xi(3,2) = lambda_3_xi(2);
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % Polynomial Degree k = 2
            %
            %   3
            %   |\
            %   | \
            %   |  \
            %   6   5
            %   |    \
            %   |     \
            %   |      \
            %   1---4---2
            %
            case 2
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Functions
                %
                Nhat(1) = 2*lambda_1*(2*lambda_1-1)/2;
                Nhat(2) = 2*lambda_2*(2*lambda_2-1)/2;
                Nhat(3) = 2*lambda_3*(2*lambda_3-1)/2;
                Nhat(4) = 2*lambda_1*2*lambda_2;
                Nhat(5) = 2*lambda_2*2*lambda_3;
                Nhat(6) = 2*lambda_3*2*lambda_1;
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Derivatives
                %
                Nhat_xi(1,1) = 2*lambda_1_xi(1)*(2*lambda_1-1)/2 + 2*lambda_1*(2*lambda_1_xi(1))/2;
                Nhat_xi(1,2) = 2*lambda_1_xi(2)*(2*lambda_1-1)/2 + 2*lambda_1*(2*lambda_1_xi(2))/2;
                Nhat_xi(2,1) = 2*lambda_2_xi(1)*(2*lambda_2-1)/2 + 2*lambda_2*(2*lambda_2_xi(1))/2;
                Nhat_xi(2,2) = 2*lambda_2_xi(2)*(2*lambda_2-1)/2 + 2*lambda_2*(2*lambda_2_xi(2))/2;
                Nhat_xi(3,1) = 2*lambda_3_xi(1)*(2*lambda_3-1)/2 + 2*lambda_3*(2*lambda_3_xi(1))/2;
                Nhat_xi(3,2) = 2*lambda_3_xi(2)*(2*lambda_3-1)/2 + 2*lambda_3*(2*lambda_3_xi(2))/2;
                Nhat_xi(4,1) = 2*lambda_1_xi(1)*2*lambda_2 + 2*lambda_1*2*lambda_2_xi(1);
                Nhat_xi(4,2) = 2*lambda_1_xi(2)*2*lambda_2 + 2*lambda_1*2*lambda_2_xi(2);
                Nhat_xi(5,1) = 2*lambda_2_xi(1)*2*lambda_3 + 2*lambda_2*2*lambda_3_xi(1);
                Nhat_xi(5,2) = 2*lambda_2_xi(2)*2*lambda_3 + 2*lambda_2*2*lambda_3_xi(2);
                Nhat_xi(6,1) = 2*lambda_3_xi(1)*2*lambda_1 + 2*lambda_3*2*lambda_1_xi(1);
                Nhat_xi(6,2) = 2*lambda_3_xi(2)*2*lambda_1 + 2*lambda_3*2*lambda_1_xi(2);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % Polynomial Degree k = 3
            %
            %   3
            %   |\
            %   | \
            %   8  7
            %   |   \
            %   9 10 6
            %   |     \
            %   |      \
            %   1--4-5--2
            %
            case 3
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Functions
                %
                Nhat(1) = 3*lambda_1*(3*lambda_1-1)/2*(3*lambda_1-2)/3;
                Nhat(2) = 3*lambda_2*(3*lambda_2-1)/2*(3*lambda_2-2)/3;
                Nhat(3) = 3*lambda_3*(3*lambda_3-1)/2*(3*lambda_3-2)/3;
                Nhat(4) = 3*lambda_1*(3*lambda_1-1)/2*3*lambda_2;
                Nhat(5) = 3*lambda_1*3*lambda_2*(3*lambda_2-1)/2;
                Nhat(6) = 3*lambda_2*(3*lambda_2-1)/2*3*lambda_3;
                Nhat(7) = 3*lambda_2*3*lambda_3*(3*lambda_3-1)/2;
                Nhat(8) = 3*lambda_3*(3*lambda_3-1)/2*3*lambda_1;
                Nhat(9) = 3*lambda_3*3*lambda_1*(3*lambda_1-1)/2;
                Nhat(10) = 3*lambda_1*3*lambda_2*3*lambda_3;
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Derivatives
                %
                Nhat_xi(1,1) = 3*lambda_1_xi(1)*(3*lambda_1-1)/2*(3*lambda_1-2)/3 + 3*lambda_1*(3*lambda_1_xi(1))/2*(3*lambda_1-2)/3 + 3*lambda_1*(3*lambda_1-1)/2*(3*lambda_1_xi(1))/3;
                Nhat_xi(1,2) = 3*lambda_1_xi(2)*(3*lambda_1-1)/2*(3*lambda_1-2)/3 + 3*lambda_1*(3*lambda_1_xi(2))/2*(3*lambda_1-2)/3 + 3*lambda_1*(3*lambda_1-1)/2*(3*lambda_1_xi(2))/3;
                Nhat_xi(2,1) = 3*lambda_2_xi(1)*(3*lambda_2-1)/2*(3*lambda_2-2)/3 + 3*lambda_2*(3*lambda_2_xi(1))/2*(3*lambda_2-2)/3 + 3*lambda_2*(3*lambda_2-1)/2*(3*lambda_2_xi(1))/3;
                Nhat_xi(2,2) = 3*lambda_2_xi(2)*(3*lambda_2-1)/2*(3*lambda_2-2)/3 + 3*lambda_2*(3*lambda_2_xi(2))/2*(3*lambda_2-2)/3 + 3*lambda_2*(3*lambda_2-1)/2*(3*lambda_2_xi(2))/3;
                Nhat_xi(3,1) = 3*lambda_3_xi(1)*(3*lambda_3-1)/2*(3*lambda_3-2)/3 + 3*lambda_3*(3*lambda_3_xi(1))/2*(3*lambda_3-2)/3 + 3*lambda_3*(3*lambda_3-1)/2*(3*lambda_3_xi(1))/3;
                Nhat_xi(3,2) = 3*lambda_3_xi(2)*(3*lambda_3-1)/2*(3*lambda_3-2)/3 + 3*lambda_3*(3*lambda_3_xi(2))/2*(3*lambda_3-2)/3 + 3*lambda_3*(3*lambda_3-1)/2*(3*lambda_3_xi(2))/3;               
                Nhat_xi(4,1) = 3*lambda_1_xi(1)*(3*lambda_1-1)/2*3*lambda_2 + 3*lambda_1*(3*lambda_1_xi(1))/2*3*lambda_2 + 3*lambda_1*(3*lambda_1-1)/2*3*lambda_2_xi(1);
                Nhat_xi(4,2) = 3*lambda_1_xi(2)*(3*lambda_1-1)/2*3*lambda_2 + 3*lambda_1*(3*lambda_1_xi(2))/2*3*lambda_2 + 3*lambda_1*(3*lambda_1-1)/2*3*lambda_2_xi(2);
                Nhat_xi(5,1) = 3*lambda_1_xi(1)*3*lambda_2*(3*lambda_2-1)/2 + 3*lambda_1*3*lambda_2_xi(1)*(3*lambda_2-1)/2 + 3*lambda_1*3*lambda_2*(3*lambda_2_xi(1))/2;
                Nhat_xi(5,2) = 3*lambda_1_xi(2)*3*lambda_2*(3*lambda_2-1)/2 + 3*lambda_1*3*lambda_2_xi(2)*(3*lambda_2-1)/2 + 3*lambda_1*3*lambda_2*(3*lambda_2_xi(2))/2;
                Nhat_xi(6,1) = 3*lambda_2_xi(1)*(3*lambda_2-1)/2*3*lambda_3 + 3*lambda_2*(3*lambda_2_xi(1))/2*3*lambda_3 + 3*lambda_2*(3*lambda_2-1)/2*3*lambda_3_xi(1);
                Nhat_xi(6,2) = 3*lambda_2_xi(2)*(3*lambda_2-1)/2*3*lambda_3 + 3*lambda_2*(3*lambda_2_xi(2))/2*3*lambda_3 + 3*lambda_2*(3*lambda_2-1)/2*3*lambda_3_xi(2);
                Nhat_xi(7,1) = 3*lambda_2_xi(1)*3*lambda_3*(3*lambda_3-1)/2 + 3*lambda_2*3*lambda_3_xi(1)*(3*lambda_3-1)/2 + 3*lambda_2*3*lambda_3*(3*lambda_3_xi(1))/2;
                Nhat_xi(7,2) = 3*lambda_2_xi(2)*3*lambda_3*(3*lambda_3-1)/2 + 3*lambda_2*3*lambda_3_xi(2)*(3*lambda_3-1)/2 + 3*lambda_2*3*lambda_3*(3*lambda_3_xi(2))/2;
                Nhat_xi(8,1) = 3*lambda_3_xi(1)*(3*lambda_3-1)/2*3*lambda_1 + 3*lambda_3*(3*lambda_3_xi(1))/2*3*lambda_1 + 3*lambda_3*(3*lambda_3-1)/2*3*lambda_1_xi(1);
                Nhat_xi(8,2) = 3*lambda_3_xi(2)*(3*lambda_3-1)/2*3*lambda_1 + 3*lambda_3*(3*lambda_3_xi(2))/2*3*lambda_1 + 3*lambda_3*(3*lambda_3-1)/2*3*lambda_1_xi(2);
                Nhat_xi(9,1) = 3*lambda_3_xi(1)*3*lambda_1*(3*lambda_1-1)/2 + 3*lambda_3*3*lambda_1_xi(1)*(3*lambda_1-1)/2 + 3*lambda_3*3*lambda_1*(3*lambda_1_xi(1))/2;
                Nhat_xi(9,2) = 3*lambda_3_xi(2)*3*lambda_1*(3*lambda_1-1)/2 + 3*lambda_3*3*lambda_1_xi(2)*(3*lambda_1-1)/2 + 3*lambda_3*3*lambda_1*(3*lambda_1_xi(2))/2;
                Nhat_xi(10,1) = 3*lambda_1_xi(1)*3*lambda_2*3*lambda_3 + 3*lambda_1*3*lambda_2_xi(1)*3*lambda_3 + 3*lambda_1*3*lambda_2*3*lambda_3_xi(1);
                Nhat_xi(10,2) = 3*lambda_1_xi(2)*3*lambda_2*3*lambda_3 + 3*lambda_1*3*lambda_2_xi(2)*3*lambda_3 + 3*lambda_1*3*lambda_2*3*lambda_3_xi(2);
               
        end
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %              Quadrilateral Finite Elements
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    case 'QUAD'

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Shape Function Computations
        
        switch k
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % Polynomial Degree k = 1
            %
            %   4-----3
            %   |     |
            %   |     |
            %   |     |
            %   1-----2
            %
            case 1
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Functions
                %
                Nhat(1) = 0.5*(1-xi_1)*0.5*(1-xi_2);
                Nhat(2) = 0.5*(1+xi_1)*0.5*(1-xi_2);
                Nhat(3) = 0.5*(1+xi_1)*0.5*(1+xi_2);
                Nhat(4) = 0.5*(1-xi_1)*0.5*(1+xi_2);
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Derivatives
                %
                Nhat_xi(1,1) = 0.5*(-1)*0.5*(1-xi_2);
                Nhat_xi(1,2) = 0.5*(1-xi_1)*0.5*(-1);
                Nhat_xi(2,1) = 0.5*(1)*0.5*(1-xi_2);
                Nhat_xi(2,2) = 0.5*(1+xi_1)*0.5*(-1);
                Nhat_xi(3,1) = 0.5*(1)*0.5*(1+xi_2);
                Nhat_xi(3,2) = 0.5*(1+xi_1)*0.5*(1);
                Nhat_xi(4,1) = 0.5*(-1)*0.5*(1+xi_2);
                Nhat_xi(4,2) = 0.5*(1-xi_1)*0.5*(1);
                
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % Polynomial Degree k = 2
            %
            %   4--7--3
            %   |     |
            %   8  9  6
            %   |     |
            %   1--5--2
            %    
            case 2
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Functions
                %
                Nhat(1) = 0.5*(1-xi_1)*(-xi_1)*0.5*(1-xi_2)*(-xi_2);
                Nhat(2) = 0.5*(1+xi_1)*(xi_1)*0.5*(1-xi_2)*(-xi_2);
                Nhat(3) = 0.5*(1+xi_1)*(xi_1)*0.5*(1+xi_2)*(xi_2);
                Nhat(4) = 0.5*(1-xi_1)*(-xi_1)*0.5*(1+xi_2)*(xi_2);
                Nhat(5) = (1-xi_1)*(1+xi_1)*0.5*(1-xi_2)*(-xi_2);
                Nhat(6) = 0.5*(1+xi_1)*(xi_1)*(1-xi_2)*(1+xi_2);
                Nhat(7) = (1-xi_1)*(1+xi_1)*0.5*(1+xi_2)*(xi_2);
                Nhat(8) = 0.5*(1-xi_1)*(-xi_1)*(1-xi_2)*(1+xi_2);
                Nhat(9) = (1-xi_1)*(1+xi_1)*(1-xi_2)*(1+xi_2);
                
                %%%%%%%%%%%%%%%%%%%%
                % Shape Derivatives
                %
                Nhat_xi(1,1) = 0.5*(-1)*(-xi_1)*0.5*(1-xi_2)*(-xi_2) + 0.5*(1-xi_1)*(-1)*0.5*(1-xi_2)*(-xi_2);
                Nhat_xi(1,2) = 0.5*(1-xi_1)*(-xi_1)*0.5*(-1)*(-xi_2) + 0.5*(1-xi_1)*(-xi_1)*0.5*(1-xi_2)*(-1);
                Nhat_xi(2,1) = 0.5*(1)*(xi_1)*0.5*(1-xi_2)*(-xi_2) + 0.5*(1+xi_1)*(1)*0.5*(1-xi_2)*(-xi_2);
                Nhat_xi(2,2) = 0.5*(1+xi_1)*(xi_1)*0.5*(-1)*(-xi_2) + 0.5*(1+xi_1)*(xi_1)*0.5*(1-xi_2)*(-1);
                Nhat_xi(3,1) = 0.5*(1)*(xi_1)*0.5*(1+xi_2)*(xi_2) + 0.5*(1+xi_1)*(1)*0.5*(1+xi_2)*(xi_2);
                Nhat_xi(3,2) = 0.5*(1+xi_1)*(xi_1)*0.5*(1)*(xi_2) + 0.5*(1+xi_1)*(xi_1)*0.5*(1+xi_2)*(1);
                Nhat_xi(4,1) = 0.5*(-1)*(-xi_1)*0.5*(1+xi_2)*(xi_2) + 0.5*(1-xi_1)*(-1)*0.5*(1+xi_2)*(xi_2);
                Nhat_xi(4,2) = 0.5*(1-xi_1)*(-xi_1)*0.5*(1)*(xi_2) + 0.5*(1-xi_1)*(-xi_1)*0.5*(1+xi_2)*(1);                
                Nhat_xi(5,1) = (-1)*(1+xi_1)*0.5*(1-xi_2)*(-xi_2) + (1-xi_1)*(1)*0.5*(1-xi_2)*(-xi_2);
                Nhat_xi(5,2) = (1-xi_1)*(1+xi_1)*0.5*(-1)*(-xi_2) + (1-xi_1)*(1+xi_1)*0.5*(1-xi_2)*(-1);
                Nhat_xi(6,1) = 0.5*(1)*(xi_1)*(1-xi_2)*(1+xi_2) + 0.5*(1+xi_1)*(1)*(1-xi_2)*(1+xi_2);
                Nhat_xi(6,2) = 0.5*(1+xi_1)*(xi_1)*(-1)*(1+xi_2) + 0.5*(1+xi_1)*(xi_1)*(1-xi_2)*(1);
                Nhat_xi(7,1) = (-1)*(1+xi_1)*0.5*(1+xi_2)*(xi_2) + (1-xi_1)*(1)*0.5*(1+xi_2)*(xi_2);
                Nhat_xi(7,2) = (1-xi_1)*(1+xi_1)*0.5*(1)*(xi_2) + (1-xi_1)*(1+xi_1)*0.5*(1+xi_2)*(1);
                Nhat_xi(8,1) = 0.5*(-1)*(-xi_1)*(1-xi_2)*(1+xi_2) + 0.5*(1-xi_1)*(-1)*(1-xi_2)*(1+xi_2);
                Nhat_xi(8,2) = 0.5*(1-xi_1)*(-xi_1)*(-1)*(1+xi_2) + 0.5*(1-xi_1)*(-xi_1)*(1-xi_2)*(1);
                Nhat_xi(9,1) = (-1)*(1+xi_1)*(1-xi_2)*(1+xi_2) + (1-xi_1)*(1)*(1-xi_2)*(1+xi_2);
                Nhat_xi(9,2) = (1-xi_1)*(1+xi_1)*(-1)*(1+xi_2) + (1-xi_1)*(1+xi_1)*(1-xi_2)*(1);
                
        end
end
       