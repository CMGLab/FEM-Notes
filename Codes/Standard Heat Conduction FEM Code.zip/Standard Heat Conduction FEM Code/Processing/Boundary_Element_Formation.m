%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Boundary_Element_Formation
%
% Input:  B_Nhat = parent boundary element shape function values
%         B_Nhat_xi = parent boundary element shape function derivatives
%         B_Nodes = node array for given boundary element
%         B_Quad_Wts = parent boundary element quadrature weights
%         h = applied heat flux function handle
%         beta = convective heat transfer coefficient function handle
%         T_R = temperature of surrounding convective medium
%         Neumann = Neumann identifier for given boundary element
%         Robin = Robin identifier for given boundary element
%
% Output: keb = boundary element stiffness matrix
%         feb = boundary element force vector
%
% Purpose: Form boundary element stiffness matrix and force vector
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [keb,feb] = Boundary_Element_Formation(B_Nhat,B_Nhat_xi,B_Nodes,B_Quad_Wts,h,beta,T_R,Neumann,Robin)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nenb = size(B_Nodes,1);
nqb = size(B_Quad_Wts,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize boundary element stiffness matrix and force vector

keb = zeros(nenb,nenb);
feb = zeros(nenb,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop over parent boundary element quadrature points

for l = 1:nqb
    
    %%%
    % Compute physical basis function values, position, and Jacobian

    [B_N,xb,jb] = Boundary_Shape_Physical(B_Nhat(:,l),B_Nhat_xi(:,l),B_Nodes);
    
    %%%
    % Is boundary element on a Neumann sub-boundary?

    if Neumann > 0
        
        h_loc = h(xb(1),xb(2),Neumann);
        for a = 1:nenb
            feb(a) = feb(a) + h_loc*B_N(a)*B_Quad_Wts(l)*jb;
        end

    %%%
    % Is boundary element on a Robin sub-boundary?
    
    elseif Robin > 0
    
        beta_loc = beta(xb(1),xb(2),Robin);
        T_R_loc = T_R(xb(1),xb(2),Robin);
        for a = 1:nenb
            for b = 1:nenb
                keb(a,b) = keb(a,b) + beta_loc*B_N(a)*B_N(b)*B_Quad_Wts(l)*jb;
            end
            feb(a) = feb(a) + beta_loc*B_N(a)*T_R_loc*B_Quad_Wts(l)*jb;
        end
        
    end
        
end