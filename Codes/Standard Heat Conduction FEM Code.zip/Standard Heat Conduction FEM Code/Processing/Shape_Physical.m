%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Shape_Physical
%
% Input:  Nhat = parent element shape function values
%         Nhat_xi = parent element shape function derivatives
%         Nodes = node array for given element
%
% Output: N = physical element basis function values
%         N_x = physical element basis function derivatives
%         x = physical position
%         detJ = determinant
%
% Purpose: Compute physical element basis function values and derivatives
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [N,N_x,x,detJ] = Shape_Physical(Nhat,Nhat_xi,Nodes)

%%%
% Compute physical position

x = [Nhat'*Nodes(:,1); Nhat'*Nodes(:,2)];

%%%
% Compute Jacobian

J = [Nhat_xi(:,1)'*Nodes(:,1) Nhat_xi(:,2)'*Nodes(:,1); ...
     Nhat_xi(:,1)'*Nodes(:,2) Nhat_xi(:,2)'*Nodes(:,2)];

%%%
% Compute determinant

detJ = det(J);

%%%
% Compute inverse of Jacobian

Jinv = inv(J);

%%%
% Compute physical element basis function values

N = Nhat;

%%%
% Compute physical element basis function derivatives

N_x(:,1) = Nhat_xi(:,1)*Jinv(1,1) + Nhat_xi(:,2)*Jinv(2,1);
N_x(:,2) = Nhat_xi(:,1)*Jinv(1,2) + Nhat_xi(:,2)*Jinv(2,2);