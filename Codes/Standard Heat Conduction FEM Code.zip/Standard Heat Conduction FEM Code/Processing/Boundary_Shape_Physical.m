%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Boundary_Shape_Physical
%
% Input:  B_Nhat = parent boundary element shape function values
%         B_Nhat_xi = parent boundary element shape function derivatives
%         B_Nodes = node array for given boundary element
%
% Output: B_N = physical boundary element basis function values
%         xb = physical position
%         detJb = surface determinant
%
% Purpose: Compute physical boundary element basis functions
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [B_N,xb,detJb] = Boundary_Shape_Physical(B_Nhat,B_Nhat_xi,B_Nodes)

%%%
% Compute physical position

xb = [B_Nhat'*B_Nodes(:,1); B_Nhat'*B_Nodes(:,2)];

%%%
% Compute surface determinant

detJb = sqrt((B_Nhat_xi'*B_Nodes(:,1))^2 + (B_Nhat_xi'*B_Nodes(:,2))^2);

%%%
% Compute physical boundary element basis function values

B_N = B_Nhat;