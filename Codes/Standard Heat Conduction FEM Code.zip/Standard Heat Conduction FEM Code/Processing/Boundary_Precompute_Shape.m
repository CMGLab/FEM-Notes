%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Boundary_Precompute_Shape
%
% Input:  k = polynomial degree
%         B_Quad_Pts = parent boundary element quadrature points
%
% Output: B_Nhat = parent boundary element shape function values
%         B_Nhat_xi = parent boundary element shape function derivatives
%
% Purpose: Compute parent boundary element shape function and derivatives
%          at all quadrature points
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [B_Nhat,B_Nhat_xi] = Boundary_Precompute_Shape(k,B_Quad_Pts)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nqb = size(B_Quad_Pts,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop over parent boundary element quadrature points

for l = 1:nqb
    xi = B_Quad_Pts(l);
    
    [B_Nhat_pt,B_Nhat_xi_pt] = Boundary_Shape_Parent(k,xi);
    
    B_Nhat(:,l) = B_Nhat_pt;
    B_Nhat_xi(:,l) = B_Nhat_xi_pt;
end