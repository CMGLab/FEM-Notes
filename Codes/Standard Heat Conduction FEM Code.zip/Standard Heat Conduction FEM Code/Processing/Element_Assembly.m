%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Element_Assembly
%
% Input:  ke = element stiffness matrix
%         fe = element force vector
%         IEN = element connectivity array for given element
%         ID = degree of freedom array
%         G = vector with applied temperature at Dirichlet nodes
%         K = global stiffness matrix
%         F = global force vector
%
% Output: K = global stiffness matrix
%         F = global force vector
%
% Purpose: Assemble element stiffness matrix and force vector
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [K,F] = Element_Assembly(ke,fe,IEN,ID,G,K,F)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nen = size(IEN,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assemble element matrix and vector into global matrix and vector

for a = 1:nen
    A = ID(IEN((a)));
    if A ~= 0
        for b = 1:nen
            B = ID(IEN((b)));
            if B ~= 0
                K(A,B) = K(A,B) + ke(a,b);
            else
                F(A) = F(A) - ke(a,b)*G(IEN(b));
            end
        end
        F(A) = F(A) + fe(a);
    end
end