%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Boundary_Shape_Parent
%
% Input:  k = polynomial degree
%         xi = location on parent boundary element
%
% Output: B_Nhat = parent boundary element shape function values
%         B_Nhat_xi = parent boundary element shape function derivatives
%
% Purpose: Compute parent boundary element shape functions and derivatives
%          at single point
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [B_Nhat,B_Nhat_xi] = Boundary_Shape_Parent(k,xi)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Shape Function Computations

switch k
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Polynomial Degree k = 1
    %
    %   1-------2
    %
    case 1
        
        %%%%%%%%%%%%%%%%%%%%
        % Shape Functions
        %
        B_Nhat(1) = 0.5*(1-xi);
        B_Nhat(2) = 0.5*(1+xi);
        
        %%%%%%%%%%%%%%%%%%%%
        % Shape Derivatives
        %
        B_Nhat_xi(1) = -0.5;
        B_Nhat_xi(2) = 0.5;
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Polynomial Degree k = 2
    %
    %   1---3---2
    %
    case 2
        
        %%%%%%%%%%%%%%%%%%%%
        % Shape Functions
        %
        B_Nhat(1) = 0.5*(1-xi)*(-xi);
        B_Nhat(2) = 0.5*(1+xi)*(xi);
        B_Nhat(3) = (1-xi)*(1+xi);
        
        %%%%%%%%%%%%%%%%%%%%
        % Shape Derivatives
        %
        B_Nhat_xi(1) = 0.5*(-1)*(-xi) + 0.5*(1-xi)*(-1);
        B_Nhat_xi(2) = 0.5*(1)*(xi) + 0.5*(1+xi)*(1);
        B_Nhat_xi(3) = (-1)*(1+xi) + (1-xi)*(1);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Polynomial Degree k = 3
    %
    %   1--3-4--2
    %
    case 3
        
        %%%%%%%%%%%%%%%%%%%%
        % Shape Functions
        %
        B_Nhat(1) = 0.5*(1-xi)*3/4*(1/3-xi)*3/2*(-1/3-xi);
        B_Nhat(2) = 0.5*(1+xi)*3/4*(-1/3+xi)*3/2*(1/3+xi);
        B_Nhat(3) = 3/2*(1/3-xi)*3/4*(1-xi)*3/2*(1+xi);
        B_Nhat(4) = 3/2*(1/3+xi)*3/4*(1+xi)*3/2*(1-xi);
        
        %%%%%%%%%%%%%%%%%%%%
        % Shape Derivatives
        %
        B_Nhat_xi(1) = 0.5*(-1)*3/4*(1/3-xi)*3/2*(-1/3-xi) + 0.5*(1-xi)*3/4*(-1)*3/2*(-1/3-xi) + 0.5*(1-xi)*3/4*(1/3-xi)*3/2*(-1);
        B_Nhat_xi(2) = 0.5*(1)*3/4*(-1/3+xi)*3/2*(1/3+xi) + 0.5*(1+xi)*3/4*(1)*3/2*(1/3+xi) + 0.5*(1+xi)*3/4*(-1/3+xi)*3/2*(1);
        B_Nhat_xi(3) = 3/2*(-1)*3/4*(1-xi)*3/2*(1+xi) + 3/2*(1/3-xi)*3/4*(-1)*3/2*(1+xi) + 3/2*(1/3-xi)*3/4*(1-xi)*3/2*(1);
        B_Nhat_xi(4) = 3/2*(1)*3/4*(1+xi)*3/2*(1-xi) + 3/2*(1/3+xi)*3/4*(1)*3/2*(1-xi) + 3/2*(1/3+xi)*3/4*(1+xi)*3/2*(-1);
        
end