%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Dirichlet_Values
%
% Input:  Nodes = node array
%         Dirichlet = node Dirichlet array
%         g = applied temperature function handle
%
% Output: G = vector with applied temperature at Dirichlet nodes
%
% Purpose: Compute applied temperature at Dirichlet nodes
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function G = Dirichlet_Values(Nodes,Dirichlet,g)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nnod = size(Dirichlet,1);
G = zeros(nnod,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop over nodes and compute/store applied temperature at Dirichlet nodes

for A = 1:nnod
    if Dirichlet(A) ~= 0
        G(A) = g(Nodes(A,1),Nodes(A,2),Dirichlet(A));
    end
end