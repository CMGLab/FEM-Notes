%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Heat_Conduction
%
% Input:  SHAPE = element shape (TRI or QUAD)
%         k = polynomial degree (1,2,3 for TRI, 1,2 for QUAD)
%         IEN = element connectivity array
%         IENB = boundary element connectivity array
%         ID = degree of freedom array
%         Nodes = node array
%         Dirichlet = node Dirichlet array
%         Neumann = edge Neumann array
%         Robin = edge Robin array
%         Subdomain = element Subdomain array
%         kappa = thermal conductivity function handle
%         f = internal heating function handle
%         g = applied temperature function handle
%         h = applied heat flux function handle
%         beta = convective heat transfer coefficient function handle
%         T_R = temperature of surrounding convective medium
%
% Output: Temperature = temperature values at nodes
%
% Purpose: Solve the 2-D heat conduction problem
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Temperature] = Heat_Conduction(SHAPE,k,IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain,kappa,f,g,h,beta,T_R)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nnod = size(Nodes,1);
nel = size(IEN,2);
nelb = size(IENB,2);
neq = max(ID);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Identify quadrature points and weights

[Quad_Pts,Quad_Wts] = Quadrature_Data(SHAPE,k);
[B_Quad_Pts,B_Quad_Wts] = Boundary_Quadrature_Data(k);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Precompute shape functions at quadrature points

[Nhat,Nhat_xi] = Precompute_Shape(SHAPE,k,Quad_Pts);
[B_Nhat,B_Nhat_xi] = Boundary_Precompute_Shape(k,B_Quad_Pts);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute applied temperature at Dirichlet nodes

G = Dirichlet_Values(Nodes,Dirichlet,g);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize stiffness matrix and force vector

K = zeros(neq,neq);
F = zeros(neq,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Form and assemble element stiffness matrices and force vectors

for e = 1:nel
    [ke,fe] = Element_Formation(Nhat,Nhat_xi,Nodes(IEN(:,e),:),Quad_Wts,kappa,f,Subdomain(e));
    [K,F] = Element_Assembly(ke,fe,IEN(:,e),ID,G,K,F);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Form and assemble boundary element stiffness matrices and force vectors

for e = 1:nelb
    [keb,feb] = Boundary_Element_Formation(B_Nhat,B_Nhat_xi,Nodes(IENB(:,e),:),B_Quad_Wts,h,beta,T_R,Neumann(e),Robin(e));
    [K,F] = Element_Assembly(keb,feb,IENB(:,e),ID,G,K,F);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve linear system for degrees of freedom

d = K\F;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute temperature at nodes

for A = 1:nnod
    if ID(A) > 0
        Temperature(A,1) = d(ID(A));
    else
        Temperature(A,1) = G(A);
    end
end