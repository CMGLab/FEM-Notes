%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Element_Formation
%
% Input:  Nhat = parent element shape function values
%         Nhat_xi = parent element shape function derivatives
%         Nodes = node array for given element
%         Quad_Wts = parent element quadrature weights
%         kappa = thermal conductivity function handle
%         f = internal heating function handle
%         Subdomain = Subdomain identifier for given element
%
% Output: ke = element stiffness matrix
%         fe = element force vector
%
% Purpose: Form element stiffness matrix and force vector
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ke,fe] = Element_Formation(Nhat,Nhat_xi,Nodes,Quad_Wts,kappa,f,Subdomain)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute sizes

nen = size(Nodes,1);
nq = size(Quad_Wts,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize element stiffness matrix and force vector

ke = zeros(nen,nen);
fe = zeros(nen,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop over parent element quadrature points

for l = 1:nq

    %%%
    % Compute basis function values, derivatives, position, and Jacobian

    [N,N_x,x,j] = Shape_Physical(Nhat(:,l),Nhat_xi(:,:,l),Nodes);
    
    %%%
    % Compute thermal conductivity and internal heating at point

    kappa_loc = kappa(x(1),x(2),Subdomain);
    f_loc = f(x(1),x(2),Subdomain);
    
    %%%
    % Compute entries at point

    for a = 1:nen
        for b = 1:nen
            ke(a,b) = ke(a,b) + kappa_loc*N_x(a,:)*N_x(b,:)'*Quad_Wts(l)*j;
        end
        fe(a) = fe(a) + f_loc*N(a)*Quad_Wts(l)*j;
    end
end