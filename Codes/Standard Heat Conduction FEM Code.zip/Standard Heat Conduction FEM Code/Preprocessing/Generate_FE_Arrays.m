%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Function: Generate_FE_Arrays
%
% Input:  FILE = file name
%         k = polynomial degree (1,2,3 for TRI, 1,2 for QUAD)
%         SHAPE = element shape (TRI or QUAD)
%
% Output: IEN = element connectivity array
%         IENB = boundary element connectivity array
%         ID = degree of freedom array
%         Nodes = node array
%         Dirichlet = node Dirichlet array
%         Neumann = edge Neumann array
%         Robin = edge Robin array
%         Subdomain = element Subdomain array
%
% Purpose: Generate FEA input files from gmsh msh file

function [IEN,IENB,ID,Nodes,Dirichlet,Neumann,Robin,Subdomain] = Generate_FE_Arrays(FILE,k,SHAPE)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%            Open File and Set Element Type and Polynomial Degreee
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid = fopen(FILE,'r');

if SHAPE == "TRI"
    nenb = k+1;
    nen = (k+2)*(k+1)/2;
elseif SHAPE == "QUAD"
    nenb = k+1;
    nen = (k+1)*(k+1);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                  MeshFormat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cur_line = fgetl(fid); % $MeshFormat
cur_line = fgetl(fid); % 4.1 0 8
cur_line = fgetl(fid); % $EndMeshFormat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                 PhysicalNames
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
cur_line = fgetl(fid); % $PhysicalNames

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Obtain Number of Subdomains and Sub-Boundaries

cur_line = fgetl(fid);
Num_Physical = sscanf(cur_line,'%f');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Count and Classify

% Data for Point Sets
Num_Point_Set = 0;
Point_Set_Index = [];

% Data for Sub-Boundaries
Num_Dirichlet = 0;
Num_Neumann = 0;
Num_Robin = 0;
SubBoundary_ID = {};
SubBoundary_Index = [];

% Data for Subdomains
Num_Subdomain = 0;
Subdomain_Index = [];

for i = 1:Num_Physical
    cur_line = fgetl(fid);
    array = textscan(cur_line,'%s %s %s');
    
    dim = str2double(array{1});
    index = str2double(array{2});
    name = array{3};
    
    switch dim
        case 0            
            Num_Point_Set = Num_Point_Set + 1;
            Point_Set_Index(index) = Num_Point_Set;
        
        case 1
            if contains(name,"Dirichlet")
                Num_Dirichlet = Num_Dirichlet + 1;
                SubBoundary_ID{index} = "Dirichlet";
                SubBoundary_Index(index) = Num_Dirichlet;
            end
            
            if contains(name,"Neumann")
                Num_Neumann = Num_Neumann + 1;
                SubBoundary_ID{index} = "Neumann";
                SubBoundary_Index(index) = Num_Neumann;
            end
            
            if contains(name,"Robin")
                Num_Robin = Num_Robin + 1;
                SubBoundary_ID{index} = "Robin";
                SubBoundary_Index(index) = Num_Robin;
            end
            
        case 2
            Num_Subdomain = Num_Subdomain + 1;
            Subdomain_Index(index) = Num_Subdomain;
    end
end

cur_line = fgetl(fid); % $EndPhysicalNames

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                   Entities
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cur_line = fgetl(fid); % $Entities

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Obtain Number of Points, Curves, and Surfaces

cur_line = fgetl(fid);
integers = sscanf(cur_line,'%f');
Num_Points = integers(1);
Num_Curves = integers(2);
Num_Surfaces = integers(3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Obtain IDs of Points, Curves, and Surfaces

Point_ID = zeros(Num_Points,1);
Curve_ID = zeros(Num_Curves,1);
Surface_ID = zeros(Num_Surfaces,1);

for i = 1:Num_Points
    cur_line = fgetl(fid);
    integers = sscanf(cur_line,'%f');
    
    if size(integers,1) == 6
        Point_ID(i) = integers(6);
    end
end

for i = 1:Num_Curves
    cur_line = fgetl(fid);
    integers = sscanf(cur_line,'%f');
    
    if size(integers,1) == 12
        Curve_ID(i) = integers(9);
    end
end

for i = 1:Num_Surfaces
    cur_line = fgetl(fid);
    integers = sscanf(cur_line,'%f');
    
    Surface_ID(i) = integers(9);
end

cur_line = fgetl(fid); % $EndEntities

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                   Nodes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cur_line = fgetl(fid); % $Nodes

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Obtain Number of Entity Blocks and Nodes

cur_line = fgetl(fid);
integers = sscanf(cur_line,'%f');
Num_EntityBlocks = integers(1);
Num_Nodes = integers(2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initialize Nodes and Dirichlet Arrays

Nodes = zeros(Num_Nodes,2);
Dirichlet = zeros(Num_Nodes,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fill In Nodes and Dirichlet Arrays

for i = 1:Num_EntityBlocks
    cur_line = fgetl(fid);
    integers = sscanf(cur_line,'%f');
    Dim = integers(1);
    Tag = integers(2);
    Num_Nodes_in_Block = integers(4);
    
    Index = zeros(Num_Nodes_in_Block,1);
    for j = 1:Num_Nodes_in_Block
        cur_line = fgetl(fid);
        integers = sscanf(cur_line,'%f');
        Index(j) = integers(1);
        
        if Dim == 0
            if Point_ID(Tag) > 0
                Dirichlet(Index(j)) = Point_Set_Index(Point_ID(Tag));
            end
        end
            
        if Dim == 1
            if Curve_ID(Tag) > 0
                if contains(SubBoundary_ID{Curve_ID(Tag)},"Dirichlet")
                    Dirichlet(Index(j)) = SubBoundary_Index(Curve_ID(Tag));
                end
            end
        end
    end
        
    for j = 1:Num_Nodes_in_Block        
        cur_line = fgetl(fid);
        integers = sscanf(cur_line,'%f');
        xLoc = integers(1);
        yLoc = integers(2);
        Nodes(Index(j),1) = xLoc;
        Nodes(Index(j),2) = yLoc;
    end
end

cur_line = fgetl(fid); % $EndNodes

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                  Elements
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cur_line = fgetl(fid); % $Elements

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Obtain Number of Entity Blocks and Elements

cur_line = fgetl(fid);
integers = sscanf(cur_line,'%f');
Num_EntityBlocks = integers(1);
Num_Elements = integers(2);

Num_1D_Elements = 0;
Num_2D_Elements = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fill In IEN, IENB, Neumann, Robin, Subdomain
% Arrays and Count

for i = 1:Num_EntityBlocks
    cur_line = fgetl(fid);
    integers = sscanf(cur_line,'%f');
    Dim = integers(1);
    Tag = integers(2);
    Type = integers(3);
    Num_Elements_in_Block = integers(4);
    
    for j = 1:Num_Elements_in_Block
        cur_line = fgetl(fid);
        
        if Dim == 1
            Num_1D_Elements = Num_1D_Elements + 1;
            
            integers = sscanf(cur_line,'%f');                       
            for k = 1:nenb
                IENB(k,Num_1D_Elements) = integers(k+1);
            end
            
            Neumann(Num_1D_Elements) = 0;
            Robin(Num_1D_Elements) = 0;
            
            if Curve_ID(Tag) > 0
                if contains(SubBoundary_ID{Curve_ID(Tag)},"Neumann")
                    Neumann(Num_1D_Elements) = SubBoundary_Index(Curve_ID(Tag));
                end
            
                if contains(SubBoundary_ID{Curve_ID(Tag)},"Robin")
                    Robin(Num_1D_Elements) = SubBoundary_Index(Curve_ID(Tag));
                end
            end
        end
        
        if Dim == 2
            Num_2D_Elements = Num_2D_Elements + 1;
            
            integers = sscanf(cur_line,'%f');                       
            for k = 1:nen
                IEN(k,Num_2D_Elements) = integers(k+1);
            end
            
            Subdomain(Num_2D_Elements) = Subdomain_Index(Surface_ID(Tag));
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              Create ID Array
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ID = zeros(Num_Nodes,1);

count = 0;

for i = 1:Num_Nodes
    if Dirichlet(i) == 0
        count = count+1;
        ID(i) = count;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                Close File
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fclose(fid);